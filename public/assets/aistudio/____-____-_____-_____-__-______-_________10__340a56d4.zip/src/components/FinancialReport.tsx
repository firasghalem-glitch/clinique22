import React, { useState, useEffect } from 'react';
import {
  FinancialStats,
  Appointment,
  Patient,
  ClinicSettings,
} from '../types';
import { clinicApi } from '../services/api';
import { isClinicToday, getClinicTodayStr } from '../utils/clinicDate';
import {
  TrendingUp,
  Calendar,
  Clock,
  DollarSign,
  Receipt,
  BarChart3,
  Printer,
  RefreshCw,
  Search,
  ArrowUpRight,
  Check,
  Edit3,
  X,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';

interface FinancialReportProps {
  patients: Patient[];
  appointments: Appointment[];
  settings: ClinicSettings;
  onOpenPatientDossier: (patientId: string) => void;
  onUpdateAppointment?: (id: string, updates: Partial<Appointment>) => Promise<void>;
  onRefreshAllData: () => Promise<void>;
  financialRefreshKey?: number;
}

export const FinancialReport: React.FC<FinancialReportProps> = ({
  patients,
  appointments,
  onOpenPatientDossier,
  onUpdateAppointment,
  onRefreshAllData,
  financialRefreshKey,
}) => {
  const [financialStats, setFinancialStats] = useState<FinancialStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [monthlyChartType, setMonthlyChartType] = useState<'bar' | 'area'>('bar');
  const [weeklyChartType, setWeeklyChartType] = useState<'bar' | 'area'>('bar');
  const [activeTab, setActiveTab] = useState<'overview' | 'monthly' | 'weekly' | 'transactions'>('overview');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [procedureFilter, setProcedureFilter] = useState<string>('all');

  const [editingCostApt, setEditingCostApt] = useState<Appointment | null>(null);
  const [editCostValue, setEditCostValue] = useState<string>('');
  const [editPaymentMethod, setEditPaymentMethod] = useState<'cash' | 'baridimob' | 'check'>('cash');
  const [isSavingCost, setIsSavingCost] = useState<boolean>(false);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const stats = await clinicApi.getFinancialStats();
      setFinancialStats(stats);
    } catch (err) {
      console.error('Failed to load financial stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [appointments, financialRefreshKey]);

  const getPatient = (id: string) => patients.find(p => p.id === id);

  const formatDZD = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      maximumFractionDigits: 0,
    }).format(amount) + ' دج';
  };

  const formatDateDZ = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  const completedAppointments = appointments
    .filter(a => a.status === 'completed')
    .sort((a, b) => (b.appointmentDate + b.appointmentTime).localeCompare(a.appointmentDate + a.appointmentTime));

  const filteredCompleted = completedAppointments.filter(apt => {
    const patient = getPatient(apt.patientId);
    const patientName = patient?.fullName.toLowerCase() || '';
    const proc = apt.procedure.toLowerCase();
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = !query ||
      patientName.includes(query) ||
      proc.includes(query) ||
      apt.appointmentDate.includes(query);
    const matchesProcedure = procedureFilter === 'all' || apt.procedure === procedureFilter;
    return matchesQuery && matchesProcedure;
  });

  const getAppointmentCost = (apt: Appointment): number => {
    return (typeof apt.cost === 'number' && apt.cost > 0) ? apt.cost : 0;
  };

  const handleOpenEditCost = (apt: Appointment) => {
    setEditingCostApt(apt);
    setEditCostValue(String(getAppointmentCost(apt)));
    setEditPaymentMethod(apt.paymentMethod || 'cash');
  };

  const handleSaveCost = async () => {
    if (!editingCostApt || !onUpdateAppointment) return;
    const costNum = parseFloat(editCostValue);
    if (isNaN(costNum) || costNum < 0) {
      alert('يرجى إدخال مبلغ صحيح.');
      return;
    }
    setIsSavingCost(true);
    try {
      // 1. تحديث الموعد بتكلفته وطريقة الدفع الجديدة
      await onUpdateAppointment(editingCostApt.id, {
        cost: costNum,
        paymentMethod: editPaymentMethod,
      });

      // 2. مزامنة فاتورة المريض في قاعدة البيانات لضمان تحديث الإحصائيات والإيرادات في كامل الصفحة
      try {
        const patientInvoices = await clinicApi.getInvoices(editingCostApt.patientId);
        const matchingInv = patientInvoices.find(
          inv => inv.appointmentId === editingCostApt.id ||
                 (inv.date === editingCostApt.appointmentDate && (inv.description?.includes(editingCostApt.procedure) || inv.notes?.includes(editingCostApt.id)))
        ) || patientInvoices.find(inv => inv.date === editingCostApt.appointmentDate);

        if (matchingInv) {
          await clinicApi.updateInvoice(matchingInv.id, {
            totalAmount: costNum,
            paidAmount: costNum,
            remainingAmount: 0,
            status: 'paid',
            paymentMethod: editPaymentMethod,
          });
        } else if (costNum > 0) {
          await clinicApi.createInvoice({
            patientId: editingCostApt.patientId,
            appointmentId: editingCostApt.id,
            date: editingCostApt.appointmentDate || getClinicTodayStr(),
            description: editingCostApt.procedure || 'كشف ومتابعة',
            totalAmount: costNum,
            paidAmount: costNum,
            paymentMethod: editPaymentMethod,
            notes: `فاتورة مسجلة للموعد #${editingCostApt.id}`,
          });
        }
      } catch (invErr) {
        console.warn('Invoice sync notice:', invErr);
      }

      // 3. إعادة تحميل كافة البيانات والإحصائيات لتنعكس فوراً على كامل صفحة التقارير والمداخيل
      await onRefreshAllData();
      await fetchStats();
      setEditingCostApt(null);
    } catch (err: any) {
      alert(err.message || 'فشل حفظ التكلفة.');
    } finally {
      setIsSavingCost(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const MonthlyTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white px-3.5 py-2.5 rounded-xl shadow-xl text-xs border border-slate-700 min-w-[160px] text-right">
          <div className="font-bold text-blue-300 mb-1">
            شهر {data.monthLabel}
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-200">
            <span>الإيراد:</span>
            <span className="font-bold font-mono text-emerald-400 tabular-nums">
              {formatDZD(data.revenue)}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-300 mt-1 border-t border-slate-800 pt-1">
            <span>المواعيد:</span>
            <span className="font-mono text-blue-400 tabular-nums">
              {data.completedCount} موعد
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  const WeeklyTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white px-3.5 py-2.5 rounded-xl shadow-xl text-xs border border-slate-700 min-w-[170px] text-right">
          <div className="font-bold text-blue-300 mb-1">
            {data.weekLabel}
          </div>
          <div className="text-[10px] text-slate-400 mb-1">
            الفترة: {formatDateDZ(data.startDate)} إلى {formatDateDZ(data.endDate)}
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-200">
            <span>الإيراد:</span>
            <span className="font-bold font-mono text-emerald-400 tabular-nums">
              {formatDZD(data.revenue)}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-300 mt-1 border-t border-slate-800 pt-1">
            <span>المواعيد المنجزة:</span>
            <span className="font-mono text-blue-400 tabular-nums">
              {data.completedCount} موعد
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  const allProcedures = Array.from(new Set(completedAppointments.map(a => a.procedure)));

  return (
    <div className="space-y-6">
      {/* Title Card */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-700 flex items-center justify-center shadow-2xs shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-heading tracking-tight">
                  التقارير المالية والمدخول السريري
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 font-heading">
                  بالدينار الجزائري (DZD)
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 font-sans leading-relaxed">
                متابعة المداخيل السنوية والشهرية والأسبوعية، وتكاليف العلاجات وطرق الدفع
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={fetchStats}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-600 ${loading ? 'animate-spin' : ''}`} />
            <span>تحديث</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs cursor-pointer"
            title="طباعة التقرير المالي"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>طباعة التقرير</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">إجمالي مدخول السنة:</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tabular-nums font-mono text-emerald-700">
              {formatDZD(financialStats?.totalRevenueYear || 0)}
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
              <span>لسنة {new Date().getFullYear()}</span>
              <span>•</span>
              <span className="text-emerald-600 font-semibold">{financialStats?.totalCompletedAppointments || 0} موعد منجز</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">إجمالي مدخول الشهر الحالي:</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tabular-nums font-mono text-blue-700">
              {formatDZD(financialStats?.totalRevenueMonth || 0)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              مجموع العلاجات المكتملة هذا الشهر
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">مدخول الأسبوع الحالي:</span>
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center font-bold">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tabular-nums font-mono text-sky-700">
              {formatDZD(financialStats?.totalRevenueWeek || 0)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              من السبت إلى الجمعة
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">متوسط الإيراد لكل موعد:</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tabular-nums font-mono text-purple-700">
              {formatDZD(financialStats?.averagePerAppointment || 0)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              معدل كل جلسة علاج منجزة
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center border-b border-slate-200 gap-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-2.5 px-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'overview'
              ? 'border-blue-600 text-blue-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          نظرة عامة
        </button>
        <button
          onClick={() => setActiveTab('monthly')}
          className={`pb-2.5 px-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'monthly'
              ? 'border-blue-600 text-blue-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          المدخول الشهري (12 شهراً)
        </button>
        <button
          onClick={() => setActiveTab('weekly')}
          className={`pb-2.5 px-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'weekly'
              ? 'border-blue-600 text-blue-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          المدخول الأسبوعي واليومي
        </button>
        <button
          onClick={() => setActiveTab('transactions')}
          className={`pb-2.5 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'transactions'
              ? 'border-blue-600 text-blue-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>سجل المدفوعات والجلسات المنجزة</span>
          <span className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded-full font-mono text-[10px]">
            {completedAppointments.length}
          </span>
        </button>
      </div>

      {/* Charts Section */}
      {(activeTab === 'overview' || activeTab === 'monthly') && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-600" />
                  <h2 className="text-sm font-bold text-slate-900">
                    المدخول الشهري التراكمي لسنة {new Date().getFullYear()}
                  </h2>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  توزيع الإيرادات الشهرية بالدينار الجزائري
                </p>
              </div>
              <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                <button
                  type="button"
                  onClick={() => setMonthlyChartType('bar')}
                  className={`px-2 py-1 text-xs font-semibold rounded cursor-pointer ${
                    monthlyChartType === 'bar' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                  title="أعمدة بيانية"
                >
                  أعمدة
                </button>
                <button
                  type="button"
                  onClick={() => setMonthlyChartType('area')}
                  className={`px-2 py-1 text-xs font-semibold rounded cursor-pointer ${
                    monthlyChartType === 'area' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                  title="مساحي متصل"
                >
                  منحنى
                </button>
              </div>
            </div>

            <div className="w-full h-72" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                {monthlyChartType === 'bar' ? (
                  <BarChart
                    data={financialStats?.monthlyRevenue || []}
                    margin={{ top: 15, right: 15, left: 0, bottom: 20 }}
                  >
                    <defs>
                      <linearGradient id="monthRevGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#059669" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#10b981" stopOpacity={0.6} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis
                      dataKey="monthLabel"
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      interval={0}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      tickFormatter={(val) => `${val / 1000}k`}
                    />
                    <Tooltip content={<MonthlyTooltip />} cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }} />
                    <Bar
                      dataKey="revenue"
                      name="الإيراد"
                      fill="url(#monthRevGrad)"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                    />
                  </BarChart>
                ) : (
                  <AreaChart
                    data={financialStats?.monthlyRevenue || []}
                    margin={{ top: 15, right: 15, left: 0, bottom: 20 }}
                  >
                    <defs>
                      <linearGradient id="monthRevAreaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#059669" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="#059669" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis
                      dataKey="monthLabel"
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      interval={0}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      tickFormatter={(val) => `${val / 1000}k`}
                    />
                    <Tooltip content={<MonthlyTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      name="الإيراد"
                      stroke="#059669"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#monthRevAreaGrad)"
                    />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-sky-600" />
                  <h2 className="text-sm font-bold text-slate-900">
                    مقارنة الأسابيع الأخيرة
                  </h2>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  تطور الإيراد خلال آخر 8 أسابيع
                </p>
              </div>
              <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                <button
                  type="button"
                  onClick={() => setWeeklyChartType('bar')}
                  className={`px-2 py-1 text-xs font-semibold rounded cursor-pointer ${
                    weeklyChartType === 'bar' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                  title="أعمدة"
                >
                  أعمدة
                </button>
                <button
                  type="button"
                  onClick={() => setWeeklyChartType('area')}
                  className={`px-2 py-1 text-xs font-semibold rounded cursor-pointer ${
                    weeklyChartType === 'area' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                  title="منحنى"
                >
                  منحنى
                </button>
              </div>
            </div>

            <div className="w-full h-72" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                {weeklyChartType === 'bar' ? (
                  <BarChart
                    data={financialStats?.weeklyRevenue || []}
                    margin={{ top: 15, right: 15, left: 0, bottom: 20 }}
                  >
                    <defs>
                      <linearGradient id="weekRevGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#0284c7" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#38bdf8" stopOpacity={0.6} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis
                      dataKey="weekLabel"
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      tickFormatter={(val) => `${val / 1000}k`}
                    />
                    <Tooltip content={<WeeklyTooltip />} cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }} />
                    <Bar
                      dataKey="revenue"
                      name="الإيراد"
                      fill="url(#weekRevGrad)"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                    />
                  </BarChart>
                ) : (
                  <AreaChart
                    data={financialStats?.weeklyRevenue || []}
                    margin={{ top: 15, right: 15, left: 0, bottom: 20 }}
                  >
                    <defs>
                      <linearGradient id="weekRevAreaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#0284c7" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="#0284c7" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis
                      dataKey="weekLabel"
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                    />
                    <YAxis
                      stroke="#94a3b8"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      tick={{ fill: '#64748b' }}
                      tickFormatter={(val) => `${val / 1000}k`}
                    />
                    <Tooltip content={<WeeklyTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      name="الإيراد"
                      stroke="#0284c7"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#weekRevAreaGrad)"
                    />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Daily Breakdown This Week */}
      {(activeTab === 'overview' || activeTab === 'weekly') && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                المدخول اليومي لهذا الأسبوع (السبت - الجمعة)
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                توزيع الإيراد وعدد المواعيد المنجزة يومياً
              </p>
            </div>
            <span className="text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-md border border-sky-200">
              مجموع الأسبوع: {formatDZD(financialStats?.totalRevenueWeek || 0)}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {(financialStats?.dailyRevenueThisWeek || []).map((day, idx) => {
              const isToday = isClinicToday(day.date);
              return (
                <div
                  key={idx}
                  className={`p-3.5 rounded-lg border text-center transition-all ${
                    isToday
                      ? 'bg-blue-50/70 border-blue-300 ring-1 ring-blue-400'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span className="text-xs font-bold text-slate-800">{day.dayName}</span>
                    {isToday && (
                      <span className="text-[9px] bg-blue-600 text-white px-1 rounded font-bold">اليوم</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                    {formatDateDZ(day.date)}
                  </div>
                  <div className="mt-2 text-sm font-bold font-mono text-emerald-700 tabular-nums">
                    {formatDZD(day.revenue)}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {day.count} {day.count === 1 ? 'جلسة' : day.count === 2 ? 'جلستان' : 'جلسات'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Procedure Breakdown */}
      {(activeTab === 'overview' || activeTab === 'monthly') && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                توزيع الإيرادات حسب نوع العلاج والإجراء السريري
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                النسبة المئوية ومجموع الدخل لكل إجراء طبي
              </p>
            </div>
            <span className="text-xs text-slate-500">
              مرتبة حسب الأكثر دخلاً
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {(financialStats?.procedureBreakdown || []).map((item, idx) => (
              <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800">{item.procedure}</span>
                  <span className="font-mono text-slate-500">{item.count} موعد</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold font-mono text-emerald-700">{formatDZD(item.revenue)}</span>
                  <span className="text-xs font-semibold text-blue-700 font-mono">{item.percentage}%</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all"
                    style={{ width: `${Math.min(item.percentage, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transactions Table */}
      {(activeTab === 'overview' || activeTab === 'transactions') && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                سجل المواعيد المنجزة والمدفوعات
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                قائمة المعاملات السريرية المكتملة مع إمكانية تعديل السعر
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="ابحث بالاسم أو الإجراء..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-9 pl-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs w-52 focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <select
                value={procedureFilter}
                onChange={(e) => setProcedureFilter(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-600 cursor-pointer"
              >
                <option value="all">كل الإجراءات</option>
                {allProcedures.map((p, i) => (
                  <option key={i} value={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                <tr>
                  <th className="py-2.5 px-3">التاريخ والوقت</th>
                  <th className="py-2.5 px-3">اسم المريض</th>
                  <th className="py-2.5 px-3">الإجراء الطبي المنجز</th>
                  <th className="py-2.5 px-3">طريقة الدفع</th>
                  <th className="py-2.5 px-3">المبلغ (DZD)</th>
                  <th className="py-2.5 px-3 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCompleted.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      لا توجد مواعيد مكتملة مطابقة للبحث
                    </td>
                  </tr>
                ) : (
                  filteredCompleted.map((apt) => {
                    const patient = getPatient(apt.patientId);
                    const cost = getAppointmentCost(apt);
                    return (
                      <tr key={apt.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">
                          <div>{formatDateDZ(apt.appointmentDate)}</div>
                          <div className="text-[10px] text-slate-400">{apt.appointmentTime}</div>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          {patient ? (
                            <button
                              onClick={() => onOpenPatientDossier(patient.id)}
                              className="font-bold text-slate-900 hover:text-blue-700 hover:underline text-right cursor-pointer"
                            >
                              {patient.fullName}
                            </button>
                          ) : (
                            <span className="text-slate-400">غير مسجل</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-700">
                          {apt.procedure}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                            apt.paymentMethod === 'baridimob'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : apt.paymentMethod === 'check'
                              ? 'bg-blue-50 text-blue-800 border border-blue-200'
                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          }`}>
                            {apt.paymentMethod === 'baridimob' ? 'بريدي موب (BaridiMob)' :
                              apt.paymentMethod === 'check' ? 'شيك بنكي' : 'نقداً (كاش)'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 text-sm whitespace-nowrap tabular-nums">
                          {formatDZD(cost)}
                        </td>
                        <td className="py-2.5 px-3 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleOpenEditCost(apt)}
                              className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                              title="تعديل السعر أو طريقة الدفع"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            {patient && (
                              <button
                                onClick={() => onOpenPatientDossier(patient.id)}
                                className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                                title="فتح الملف الطبي للمريض"
                              >
                                <ArrowUpRight className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>عدد المعاملات: <strong>{filteredCompleted.length}</strong></span>
            <span>
              إجمالي المعاملات المعروضة: <strong className="font-mono text-emerald-700 font-bold">{formatDZD(filteredCompleted.reduce((sum, a) => sum + getAppointmentCost(a), 0))}</strong>
            </span>
          </div>
        </div>
      )}

      {/* Edit Cost Modal */}
      {editingCostApt && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-5 space-y-4 border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-blue-600" />
                <span>تعديل تكلفة الجلسة وطريقة الدفع</span>
              </h3>
              <button
                onClick={() => setEditingCostApt(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg space-y-1">
                <div><strong>المريض:</strong> {getPatient(editingCostApt.patientId)?.fullName || 'مريض غير مسجل'}</div>
                <div><strong>الإجراء:</strong> {editingCostApt.procedure}</div>
                <div><strong>التاريخ:</strong> {formatDateDZ(editingCostApt.appointmentDate)} ({editingCostApt.appointmentTime})</div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  المبلغ المستحق (دينار جزائري):
                </label>
                <input
                  type="number"
                  min="0"
                  step="500"
                  value={editCostValue}
                  onChange={(e) => setEditCostValue(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-600"
                  placeholder="مثال: 3500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  طريقة الدفع:
                </label>
                <select
                  value={editPaymentMethod}
                  onChange={(e) => setEditPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer"
                >
                  <option value="cash">نقداً (كاش)</option>
                  <option value="baridimob">بريدي موب (BaridiMob)</option>
                  <option value="check">شيك بنكي</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setEditingCostApt(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                إلغاء
              </button>
              <button
                onClick={handleSaveCost}
                disabled={isSavingCost}
                className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isSavingCost ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                <span>حفظ التعديل</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
