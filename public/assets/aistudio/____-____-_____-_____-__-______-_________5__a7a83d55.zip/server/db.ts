import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import JSZip from 'jszip';

export interface Clinic {
  id: string; // e.g. "cln_default" or "cln_..."
  name: string;
  doctorName: string;
  ownerUserId: string;
  phone: string;
  address: string;
  storagePath: string;
  autoBackupDaily: boolean;
  smsEnabled?: boolean;
  smsProvider?: 'local_simulator' | 'custom' | 'twilio' | 'infobip';
  smsSenderName?: string;
  smsApiKey?: string;
  smsApiUrl?: string;
  smsAccountSid?: string;
  smsAutoSend24h?: boolean;
  smsReminderTemplate?: string;
  createdAt: string;
}

export interface User {
  id: string;
  clinicId: string;
  username: string;
  passwordHash: string;
  salt: string;
  recoveryKeyHash?: string;
  fullName: string;
  role: 'doctor' | 'assistant';
  isActive: boolean;
  mustChangePassword?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface Patient {
  id: string;
  clinicId: string;
  fullName: string;
  phone: string;
  birthDate: string;
  gender: 'male' | 'female';
  address: string;
  allergies: string;
  patientType: 'new' | 'returning';
  diseaseCondition?: string;
  diseaseStatus?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Appointment {
  id: string;
  clinicId: string;
  patientId: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:mm (e.g. 09:30)
  procedure: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  cost?: number; // DZD
  paymentMethod?: 'cash' | 'baridimob' | 'check';
  notes?: string;
  smsReminderSent?: boolean;
  smsReminderSentAt?: string;
  createdAt: string;
}

export interface ConditionHistoryEntry {
  id: string;
  date: string;
  conditionType: string;
  surface?: string;
  surfaces?: string[];
  diagnosis?: string;
  treatmentPlanned?: string;
  treatmentDone?: string;
  status: 'in_progress' | 'treated' | 'monitoring';
  doctorName?: string;
  cost?: number;
  notes?: string;
}

export interface DentalCondition {
  id: string;
  clinicId: string;
  patientId: string;
  toothNumber: number; // 11 to 48 (permanent), 51 to 85 (deciduous)
  conditionType: string;
  surface?: string;
  surfaces?: string[];
  surfaceDetails?: Record<string, any>;
  diagnosis?: string;
  treatmentPlanned?: string;
  treatmentDone?: string;
  doctorName?: string;
  status: 'in_progress' | 'treated' | 'monitoring';
  cost?: number; // DZD
  recordedDate: string;
  notes?: string;
  visitId?: string;
  history?: ConditionHistoryEntry[];
  updatedAt?: string;
  createdAt: string;
}

export interface ClinicalNote {
  id: string;
  clinicId: string;
  patientId: string;
  noteText: string;
  doctorName: string;
  createdAt: string;
}

export interface PatientFile {
  id: string;
  clinicId: string;
  patientId: string;
  originalName: string;
  storedName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  category: string;
  uploadDate: string;
}

export interface ClinicSettings {
  clinicName: string;
  doctorName: string;
  phone: string;
  address: string;
  storagePath: string;
  autoBackupDaily: boolean;
  smsEnabled?: boolean;
  smsProvider?: 'local_simulator' | 'custom' | 'twilio' | 'infobip';
  smsSenderName?: string;
  smsApiKey?: string;
  smsApiUrl?: string;
  smsAccountSid?: string;
  smsAutoSend24h?: boolean;
  smsReminderTemplate?: string;
}

export interface SmsLog {
  id: string;
  clinicId: string;
  appointmentId?: string;
  patientId?: string;
  patientName: string;
  phone: string;
  message: string;
  status: 'sent' | 'failed' | 'simulated';
  provider: string;
  sentAt: string;
  error?: string;
}

export interface DatabaseState {
  clinics: Clinic[];
  users: User[];
  patients: Patient[];
  appointments: Appointment[];
  dentalConditions: DentalCondition[];
  clinicalNotes: ClinicalNote[];
  patientFiles: PatientFile[];
  smsLogs?: SmsLog[];
  settings?: ClinicSettings;
}

export function resolveDataDir(): string {
  const envDir = process.env.DATA_DIR?.trim();
  if (envDir) {
    return path.isAbsolute(envDir) ? envDir : path.resolve(process.cwd(), envDir);
  }
  return path.resolve(process.cwd(), 'clinic_data');
}

export const DATA_DIR = resolveDataDir();
export const DB_FILE = path.join(DATA_DIR, 'clinic_database.json');
export const DEFAULT_STORAGE_PATH = path.join(DATA_DIR, 'patient_files');
export const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
export const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');

export function isPersistentEnvironment(): boolean {
  if (process.env.K_SERVICE || process.env.K_REVISION || process.env.CLOUD_RUN_JOB) {
    return false;
  }
  const appUrl = (process.env.APP_URL || '').toLowerCase();
  if (appUrl.includes('run.app')) {
    return false;
  }
  return true;
}

export function getStorageType(): 'persistent_local' | 'ephemeral_cloud' {
  return isPersistentEnvironment() ? 'persistent_local' : 'ephemeral_cloud';
}

export function getDbFilePath(): string {
  return DB_FILE;
}

export function getDataDirPath(): string {
  return DATA_DIR;
}

export function hashPassword(password: string, salt: string): string {
  const derivedKey = crypto.scryptSync(password, salt, 64, {
    N: 16384,
    r: 8,
    p: 1,
  });
  return derivedKey.toString('hex');
}

export function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

export function sanitizeFolderName(name: string): string {
  return name.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').trim();
}

export const DEFAULT_SMS_REMINDER_TEMPLATE = 'مرحباً {patientName}، نذكركم بموعدكم في {clinicName} يوم {date} على الساعة {time} مع {doctorName}. الإجراء: {procedure}. للاستفسار: {phone}. دمتم بصحة وعافية.';

export class ClinicDatabase {
  private state: DatabaseState;
  private saveTimeout: NodeJS.Timeout | null = null;

  constructor() {
    this.ensureDirectories();
    this.state = this.loadState();
  }

  public getDbFilePath(): string {
    return DB_FILE;
  }

  public getDataDirPath(): string {
    return DATA_DIR;
  }

  public getState(): DatabaseState {
    return this.state;
  }

  private ensureDirectories() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DEFAULT_STORAGE_PATH)) {
      fs.mkdirSync(DEFAULT_STORAGE_PATH, { recursive: true });
    }
    if (!fs.existsSync(BACKUPS_DIR)) {
      fs.mkdirSync(BACKUPS_DIR, { recursive: true });
    }
  }

  public getStoragePath(clinicId?: string): string {
    const clinic = clinicId ? this.getClinicById(clinicId) : this.state.clinics?.[0];
    const configuredPath = clinic?.storagePath || this.state.settings?.storagePath;
    if (configuredPath && configuredPath.trim()) {
      try {
        const resolved = path.isAbsolute(configuredPath.trim())
          ? configuredPath.trim()
          : path.resolve(process.cwd(), configuredPath.trim());
        if (!fs.existsSync(resolved)) {
          fs.mkdirSync(resolved, { recursive: true });
        }
        return resolved;
      } catch (err) {
        console.warn('Could not initialize custom storage path, fallback to default:', err);
      }
    }
    return DEFAULT_STORAGE_PATH;
  }

  public getPatientFolderPath(patient: Patient): string {
    const rootPath = this.getStoragePath(patient.clinicId);
    const clinicSubfolder = patient.clinicId ? `clinic_${patient.clinicId}` : 'clinic_default';
    const folderName = `${sanitizeFolderName(patient.fullName)}_${patient.id}`;
    const fullPath = path.join(rootPath, clinicSubfolder, folderName);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
    }
    return fullPath;
  }

  private tryRestoreFromBackups(): DatabaseState | null {
    // Check rolling backups .bak1 .. .bak5
    const backupCandidates = [
      path.join(DATA_DIR, 'clinic_database.bak1.json'),
      path.join(DATA_DIR, 'clinic_database.bak2.json'),
      path.join(DATA_DIR, 'clinic_database.bak3.json'),
      path.join(DATA_DIR, 'clinic_database.bak4.json'),
      path.join(DATA_DIR, 'clinic_database.bak5.json'),
    ];

    // Also check daily backups in BACKUPS_DIR
    if (fs.existsSync(BACKUPS_DIR)) {
      try {
        const dailyFiles = fs.readdirSync(BACKUPS_DIR)
          .filter(f => f.startsWith('clinic_database_') && f.endsWith('.json'))
          .sort()
          .reverse()
          .map(f => path.join(BACKUPS_DIR, f));
        backupCandidates.push(...dailyFiles);
      } catch {}
    }

    for (const candidate of backupCandidates) {
      if (fs.existsSync(candidate)) {
        try {
          const bRaw = fs.readFileSync(candidate, 'utf-8');
          const bParsed = JSON.parse(bRaw);
          const restoredState = this.migrateAndSanitizeState(bParsed);
          console.warn(`[DATABASE RECOVERY] Successfully recovered database state from backup: ${candidate}`);
          this.saveStateSync(restoredState);
          return restoredState;
        } catch (bErr) {
          console.warn(`[DATABASE RECOVERY] Backup candidate ${candidate} was not parseable:`, bErr);
        }
      }
    }

    return null;
  }

  private loadState(): DatabaseState {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return this.migrateAndSanitizeState(parsed);
      } catch (err: any) {
        console.error(`[DATABASE CRITICAL] Error reading or parsing ${DB_FILE}:`, err);
        // Save corrupt file for recovery - DO NOT OVERWRITE!
        const corruptFile = path.join(DATA_DIR, `clinic_database.corrupt-${Date.now()}.json`);
        try {
          fs.copyFileSync(DB_FILE, corruptFile);
          console.warn(`[DATABASE SAFETY] Preserved corrupt database file to: ${corruptFile}`);
        } catch (copyErr) {
          console.error(`[DATABASE SAFETY] Could not preserve corrupt file:`, copyErr);
        }

        const restored = this.tryRestoreFromBackups();
        if (restored) return restored;

        // If no backup could be loaded, STOP WITH ERROR - NEVER OVERWRITE WITH DUMMY DATA!
        console.error(`[FATAL DATABASE ERROR] فشلت قراءة قاعدة البيانات وتبيّن أن الملف تالف، ولم يتم العثور على أي نسخة احتياطية صالحة.`);
        throw new Error(`تعذّر الوصول إلى قاعدة بيانات العيادة: ملف البيانات تالف ولا توجد نسخ احتياطية قابلة للاستعادة.`);
      }
    }

    // DB_FILE is missing - auto-restore if any valid backup exists in bak1..bak5 or backups dir
    console.warn(`[DATABASE RECOVERY] ملف قاعدة البيانات ${DB_FILE} غير موجود. جاري البحث في النسخ الاحتياطية المتاحة...`);
    const restoredFromBackup = this.tryRestoreFromBackups();
    if (restoredFromBackup) {
      console.log(`[DATABASE RECOVERY] تم استعادة قاعدة البيانات تلقائياً من أحدث نسخة احتياطية سليمة بنجاح.`);
      return restoredFromBackup;
    }

    // Only create initial seed if DB_FILE does not exist AND no valid backups exist anywhere
    console.log(`[DATABASE INITIALIZATION] No database file or valid backups found at ${DB_FILE}. Creating initial clean state.`);
    const defaultState = this.createInitialSeed();
    this.saveStateSync(defaultState);
    return defaultState;
  }

  private migrateAndSanitizeState(parsed: any): DatabaseState {
    parsed.smsLogs = parsed.smsLogs || [];
    parsed.patients = parsed.patients || [];
    parsed.appointments = parsed.appointments || [];
    parsed.dentalConditions = parsed.dentalConditions || [];
    parsed.clinicalNotes = parsed.clinicalNotes || [];
    parsed.patientFiles = parsed.patientFiles || [];
    parsed.users = parsed.users || [];

    // Ensure clinics array exists
    if (!parsed.clinics || !Array.isArray(parsed.clinics) || parsed.clinics.length === 0) {
      const defaultClinic: Clinic = {
        id: 'cln-default',
        name: parsed.settings?.clinicName || 'عيادة النور لطب وجراحة الأسنان',
        doctorName: parsed.settings?.doctorName || 'طبيب العيادة',
        ownerUserId: parsed.users?.[0]?.id || '',
        phone: parsed.settings?.phone || '023 45 67 89 / 0550 11 22 33',
        address: parsed.settings?.address || 'الجزائر العاصمة',
        storagePath: parsed.settings?.storagePath || DEFAULT_STORAGE_PATH,
        autoBackupDaily: parsed.settings?.autoBackupDaily !== false,
        smsEnabled: parsed.settings?.smsEnabled !== false,
        smsProvider: parsed.settings?.smsProvider || 'local_simulator',
        smsSenderName: parsed.settings?.smsSenderName || 'ElNourDental',
        smsAutoSend24h: parsed.settings?.smsAutoSend24h !== false,
        smsReminderTemplate: parsed.settings?.smsReminderTemplate || DEFAULT_SMS_REMINDER_TEMPLATE,
        createdAt: new Date().toISOString(),
      };
      parsed.clinics = [defaultClinic];
    }

    const defaultClinicId = parsed.clinics[0]?.id || 'cln-default';

    // Migrate any entities missing clinicId
    for (const u of parsed.users) {
      if (!u.clinicId) u.clinicId = defaultClinicId;
    }
    for (const p of parsed.patients) {
      if (!p.clinicId) p.clinicId = defaultClinicId;
    }
    for (const a of parsed.appointments) {
      if (!a.clinicId) a.clinicId = defaultClinicId;
    }
    for (const c of parsed.dentalConditions) {
      if (!c.clinicId) c.clinicId = defaultClinicId;
    }
    for (const n of parsed.clinicalNotes) {
      if (!n.clinicId) n.clinicId = defaultClinicId;
    }
    for (const f of parsed.patientFiles) {
      if (!f.clinicId) f.clinicId = defaultClinicId;
    }
    for (const s of parsed.smsLogs) {
      if (!s.clinicId) s.clinicId = defaultClinicId;
    }

    // Do NOT re-create any hardcoded default user if users array is empty!
    // Empty users array means isFirstTimeSetup is true, allowing director setup in UI.

    return parsed as DatabaseState;
  }

  private createInitialSeed(): DatabaseState {
    const defaultClinicId = 'cln-default';

    const defaultClinic: Clinic = {
      id: defaultClinicId,
      name: 'عيادة طب وجراحة الأسنان',
      doctorName: 'طبيب العيادة',
      ownerUserId: '',
      phone: '023 45 67 89 / 0550 11 22 33',
      address: 'الجزائر العاصمة',
      storagePath: DEFAULT_STORAGE_PATH,
      autoBackupDaily: true,
      smsEnabled: true,
      smsProvider: 'local_simulator',
      smsSenderName: 'ElNourDental',
      smsAutoSend24h: true,
      smsReminderTemplate: DEFAULT_SMS_REMINDER_TEMPLATE,
      createdAt: new Date().toISOString(),
    };

    // Clean initial state with no hardcoded users - director creates own account
    return {
      clinics: [defaultClinic],
      users: [],
      patients: [],
      appointments: [],
      dentalConditions: [],
      clinicalNotes: [],
      patientFiles: [],
      smsLogs: [],
    };
  }

  private rotateBackups() {
    try {
      if (!fs.existsSync(DB_FILE)) return;

      // Only backup if DB_FILE contains valid JSON
      const currentContent = fs.readFileSync(DB_FILE, 'utf-8');
      JSON.parse(currentContent);

      // Keep last 5 rotating backups: bak1 (newest), bak2, bak3, bak4, bak5
      for (let i = 4; i >= 1; i--) {
        const src = path.join(DATA_DIR, `clinic_database.bak${i}.json`);
        const dest = path.join(DATA_DIR, `clinic_database.bak${i + 1}.json`);
        if (fs.existsSync(src)) {
          try {
            fs.copyFileSync(src, dest);
          } catch {}
        }
      }

      // Copy verified valid DB_FILE to bak1
      fs.copyFileSync(DB_FILE, path.join(DATA_DIR, 'clinic_database.bak1.json'));
    } catch (err) {
      console.warn('[DATABASE BACKUP WARN] DB_FILE is missing or invalid JSON. Skipping rotation to protect valid backups:', err);
    }
  }

  private performDailyBackup() {
    try {
      if (!fs.existsSync(DB_FILE)) return;
      if (!fs.existsSync(BACKUPS_DIR)) {
        fs.mkdirSync(BACKUPS_DIR, { recursive: true });
      }

      const todayStr = new Date().toISOString().slice(0, 10);
      const todayBackupFile = path.join(BACKUPS_DIR, `clinic_database_${todayStr}.json`);

      // Only backup once per day
      if (!fs.existsSync(todayBackupFile)) {
        fs.copyFileSync(DB_FILE, todayBackupFile);
        console.log(`[DAILY BACKUP] Created daily backup: ${todayBackupFile}`);
      }

      // Cleanup backups older than 14 days
      const files = fs.readdirSync(BACKUPS_DIR);
      const fourteenDaysAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      for (const file of files) {
        if (file.startsWith('clinic_database_') && file.endsWith('.json')) {
          const filePath = path.join(BACKUPS_DIR, file);
          const stats = fs.statSync(filePath);
          if (stats.mtimeMs < fourteenDaysAgo) {
            fs.unlinkSync(filePath);
            console.log(`[DAILY BACKUP CLEANUP] Removed backup older than 14 days: ${file}`);
          }
        }
      }
    } catch (err) {
      console.warn('[DAILY BACKUP WARN] Error performing daily backup:', err);
    }
  }

  public saveStateSync(state: DatabaseState) {
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    const serialized = JSON.stringify(state, null, 2);

    // 1. Atomic write with fsync to guarantee flush to physical disk
    const fd = fs.openSync(tempFile, 'w');
    fs.writeFileSync(fd, serialized, 'utf-8');
    fs.fsyncSync(fd);
    fs.closeSync(fd);

    // 2. Rotate previous 5 versions before replacing
    this.rotateBackups();

    // 3. Atomic rename
    fs.renameSync(tempFile, DB_FILE);

    // 4. Daily backup
    this.performDailyBackup();
  }

  private scheduleSave() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
      this.saveTimeout = null;
    }
    this.saveStateSync(this.state);
  }

  // ================= CLINICS MANAGEMENT =================
  public getAllClinics(): Clinic[] {
    return this.state.clinics || [];
  }

  public getClinicById(clinicId: string): Clinic | undefined {
    return (this.state.clinics || []).find(c => c.id === clinicId);
  }

  public reloadFromDisk(): DatabaseState {
    this.state = this.loadState();
    return this.state;
  }

  public createClinic(params: {
    clinicName: string;
    doctorName: string;
    username: string;
    passwordHash: string;
    salt: string;
    recoveryKeyHash?: string;
  }): { clinic: Clinic; user: User } {
    const clinicId = `cln_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const userId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const newClinic: Clinic = {
      id: clinicId,
      name: params.clinicName.trim() || 'عيادة طب الأسنان',
      doctorName: params.doctorName.trim() || 'د. المشرف',
      ownerUserId: userId,
      phone: '',
      address: '',
      storagePath: DEFAULT_STORAGE_PATH,
      autoBackupDaily: true,
      smsEnabled: true,
      smsProvider: 'local_simulator',
      smsSenderName: 'DentalClinic',
      smsAutoSend24h: true,
      smsReminderTemplate: DEFAULT_SMS_REMINDER_TEMPLATE,
      createdAt: now,
    };

    const newUser: User = {
      id: userId,
      clinicId,
      username: params.username.trim().toLowerCase(),
      fullName: params.doctorName.trim() || 'طبيب العيادة',
      passwordHash: params.passwordHash,
      salt: params.salt,
      recoveryKeyHash: params.recoveryKeyHash,
      role: 'doctor',
      isActive: true,
      mustChangePassword: false,
      createdAt: now,
      updatedAt: now,
    };

    if (!this.state.clinics) this.state.clinics = [];
    if (!this.state.users) this.state.users = [];

    this.state.clinics.push(newClinic);
    this.state.users.push(newUser);
    this.scheduleSave();

    return { clinic: newClinic, user: newUser };
  }

  public getClinicSettings(clinicId: string): ClinicSettings {
    const clinic = this.getClinicById(clinicId) || this.state.clinics?.[0];
    if (clinic) {
      return {
        clinicName: clinic.name,
        doctorName: clinic.doctorName,
        phone: clinic.phone,
        address: clinic.address,
        storagePath: clinic.storagePath,
        autoBackupDaily: clinic.autoBackupDaily,
        smsEnabled: clinic.smsEnabled,
        smsProvider: clinic.smsProvider,
        smsSenderName: clinic.smsSenderName,
        smsApiKey: clinic.smsApiKey,
        smsApiUrl: clinic.smsApiUrl,
        smsAccountSid: clinic.smsAccountSid,
        smsAutoSend24h: clinic.smsAutoSend24h,
        smsReminderTemplate: clinic.smsReminderTemplate,
      };
    }
    return {
      clinicName: 'عيادة طب الأسنان',
      doctorName: 'طبيب العيادة',
      phone: '',
      address: '',
      storagePath: DEFAULT_STORAGE_PATH,
      autoBackupDaily: true,
    };
  }

  public getSettings(clinicId?: string): ClinicSettings {
    return this.getClinicSettings(clinicId || this.state.clinics?.[0]?.id || 'cln-default');
  }

  public updateClinicSettings(clinicId: string, updates: Partial<ClinicSettings>): ClinicSettings {
    let clinic = this.getClinicById(clinicId);
    if (!clinic) {
      clinic = this.state.clinics?.[0];
    }
    if (clinic) {
      if (updates.clinicName !== undefined) clinic.name = updates.clinicName.trim();
      if (updates.doctorName !== undefined) clinic.doctorName = updates.doctorName.trim();
      if (updates.phone !== undefined) clinic.phone = updates.phone.trim();
      if (updates.address !== undefined) clinic.address = updates.address.trim();
      if (updates.storagePath !== undefined) clinic.storagePath = updates.storagePath.trim();
      if (updates.autoBackupDaily !== undefined) clinic.autoBackupDaily = !!updates.autoBackupDaily;
      if (updates.smsEnabled !== undefined) clinic.smsEnabled = !!updates.smsEnabled;
      if (updates.smsProvider !== undefined) clinic.smsProvider = updates.smsProvider;
      if (updates.smsSenderName !== undefined) clinic.smsSenderName = updates.smsSenderName;
      if (updates.smsApiKey !== undefined) clinic.smsApiKey = updates.smsApiKey;
      if (updates.smsApiUrl !== undefined) clinic.smsApiUrl = updates.smsApiUrl;
      if (updates.smsAccountSid !== undefined) clinic.smsAccountSid = updates.smsAccountSid;
      if (updates.smsAutoSend24h !== undefined) clinic.smsAutoSend24h = !!updates.smsAutoSend24h;
      if (updates.smsReminderTemplate !== undefined) clinic.smsReminderTemplate = updates.smsReminderTemplate;

      if (updates.storagePath && !fs.existsSync(updates.storagePath)) {
        try {
          fs.mkdirSync(updates.storagePath, { recursive: true });
        } catch (err) {
          console.error('Failed to create custom storage path:', err);
        }
      }
      this.scheduleSave();
      return this.getClinicSettings(clinic.id);
    }
    return updates as ClinicSettings;
  }

  public updateSettings(updates: Partial<ClinicSettings>, clinicId?: string): ClinicSettings {
    return this.updateClinicSettings(clinicId || this.state.clinics?.[0]?.id || 'cln-default', updates);
  }

  // ================= USERS & SECURITY (SCOPED) =================
  public getUsers(clinicId?: string): User[] {
    const list = this.state.users || [];
    if (!clinicId) return list;
    return list.filter(u => u.clinicId === clinicId);
  }

  public getUserById(id: string, clinicId?: string): User | undefined {
    const user = (this.state.users || []).find(u => u.id === id);
    if (!user) return undefined;
    if (clinicId && user.clinicId !== clinicId) return undefined;
    return user;
  }

  public getUserByUsername(username: string): User | undefined {
    if (!username) return undefined;
    const clean = username.toLowerCase().trim();
    const users = this.state.users || [];
    return users.find(u => u.username && u.username.toLowerCase().trim() === clean);
  }

  public getActiveDoctorCount(clinicId?: string): number {
    return this.getUsers(clinicId).filter(u => u.role === 'doctor' && u.isActive).length;
  }

  public createUser(userData: Omit<User, 'id' | 'createdAt'>, clinicId?: string): User {
    const targetClinicId = clinicId || userData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const newUser: User = {
      ...userData,
      clinicId: targetClinicId,
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (!this.state.users) {
      this.state.users = [];
    }
    this.state.users.push(newUser);
    this.scheduleSave();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<User>, clinicId?: string): User {
    if (!this.state.users) this.state.users = [];
    const idx = this.state.users.findIndex(u => u.id === id && (!clinicId || u.clinicId === clinicId));
    if (idx === -1) {
      throw new Error('المستخدم غير موجود.');
    }
    const current = this.state.users[idx];
    const updated: User = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.state.users[idx] = updated;
    this.scheduleSave();
    return updated;
  }

  public deleteUser(id: string, clinicId?: string): boolean {
    if (!this.state.users) return false;
    const idx = this.state.users.findIndex(u => u.id === id && (!clinicId || u.clinicId === clinicId));
    if (idx === -1) return false;
    this.state.users.splice(idx, 1);
    this.scheduleSave();
    return true;
  }

  // ================= PATIENTS (SCOPED) =================
  public getPatients(clinicId?: string): Patient[] {
    const list = this.state.patients || [];
    if (!clinicId) return list;
    return list.filter(p => p.clinicId === clinicId);
  }

  public getPatientById(id: string, clinicId?: string): Patient | undefined {
    return (this.state.patients || []).find(p => p.id === id && (!clinicId || p.clinicId === clinicId));
  }

  public createPatient(
    patientData: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'clinicId'> & { clinicId?: string },
    clinicId?: string
  ): Patient {
    const targetClinicId = clinicId || patientData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const clinicPatients = this.getPatients(targetClinicId);
    const nextNum = clinicPatients.length + 1001;
    const newId = `P${nextNum}`;
    const now = new Date().toISOString();

    const newPatient: Patient = {
      ...patientData,
      id: newId,
      clinicId: targetClinicId,
      createdAt: now,
      updatedAt: now,
    };

    if (!this.state.patients) this.state.patients = [];
    this.state.patients.push(newPatient);
    this.scheduleSave();

    // Ensure folder exists on disk
    try {
      this.getPatientFolderPath(newPatient);
    } catch (e) {}

    return newPatient;
  }

  public updatePatient(id: string, updates: Partial<Patient>, clinicId?: string): Patient | null {
    if (!this.state.patients) this.state.patients = [];
    const index = this.state.patients.findIndex(p => p.id === id && (!clinicId || p.clinicId === clinicId));
    if (index === -1) return null;

    const current = this.state.patients[index];
    const updated: Patient = {
      ...current,
      ...updates,
      id: current.id,
      clinicId: current.clinicId,
      updatedAt: new Date().toISOString(),
    };

    this.state.patients[index] = updated;
    this.scheduleSave();
    return updated;
  }

  public deletePatient(id: string, clinicId?: string): boolean {
    if (!this.state.patients) return false;
    const initialLen = this.state.patients.length;
    this.state.patients = this.state.patients.filter(p => !(p.id === id && (!clinicId || p.clinicId === clinicId)));

    if (this.state.patients.length === initialLen) {
      return false;
    }

    // Cascade delete for this clinic
    this.state.appointments = (this.state.appointments || []).filter(a => !(a.patientId === id && (!clinicId || a.clinicId === clinicId)));
    this.state.dentalConditions = (this.state.dentalConditions || []).filter(c => !(c.patientId === id && (!clinicId || c.clinicId === clinicId)));
    this.state.clinicalNotes = (this.state.clinicalNotes || []).filter(n => !(n.patientId === id && (!clinicId || n.clinicId === clinicId)));
    this.state.patientFiles = (this.state.patientFiles || []).filter(f => !(f.patientId === id && (!clinicId || f.clinicId === clinicId)));

    this.scheduleSave();
    return true;
  }

  // ================= APPOINTMENTS (SCOPED) =================
  public getAppointments(clinicId?: string): Appointment[] {
    const list = this.state.appointments || [];
    if (!clinicId) return list;
    return list.filter(a => a.clinicId === clinicId);
  }

  public getAppointmentById(id: string, clinicId?: string): Appointment | undefined {
    return (this.state.appointments || []).find(a => a.id === id && (!clinicId || a.clinicId === clinicId));
  }

  public createAppointment(
    appointmentData: Omit<Appointment, 'id' | 'createdAt' | 'clinicId'> & { clinicId?: string },
    clinicId?: string
  ): { appointment?: Appointment; error?: string } {
    const targetClinicId = clinicId || appointmentData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';

    // Conflict check in same clinic
    const conflict = (this.state.appointments || []).find(
      a =>
        a.clinicId === targetClinicId &&
        a.appointmentDate === appointmentData.appointmentDate &&
        a.appointmentTime === appointmentData.appointmentTime &&
        a.status === 'scheduled'
    );

    if (conflict) {
      const patient = this.getPatientById(conflict.patientId, targetClinicId);
      return {
        error: `توجد جلسة أخرى محجوزة في هذا التوقيت بالضبط (${appointmentData.appointmentTime}) للمريض "${patient ? patient.fullName : conflict.patientId}".`,
      };
    }

    const newAppointment: Appointment = {
      ...appointmentData,
      clinicId: targetClinicId,
      id: `APT-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
    };

    if (!this.state.appointments) this.state.appointments = [];
    this.state.appointments.push(newAppointment);
    this.scheduleSave();
    return { appointment: newAppointment };
  }

  public updateAppointment(
    id: string,
    updates: Partial<Appointment>,
    clinicId?: string
  ): { appointment?: Appointment; error?: string } {
    if (!this.state.appointments) this.state.appointments = [];
    const index = this.state.appointments.findIndex(a => a.id === id && (!clinicId || a.clinicId === clinicId));
    if (index === -1) {
      return { error: 'الموعد غير موجود' };
    }

    const current = this.state.appointments[index];
    const targetClinicId = current.clinicId;

    if (updates.appointmentDate && updates.appointmentTime && updates.status !== 'cancelled') {
      const conflict = this.state.appointments.find(
        a =>
          a.id !== id &&
          a.clinicId === targetClinicId &&
          a.appointmentDate === updates.appointmentDate &&
          a.appointmentTime === updates.appointmentTime &&
          a.status === 'scheduled'
      );
      if (conflict) {
        const patient = this.getPatientById(conflict.patientId, targetClinicId);
        return {
          error: `يوجد موعد آخر مسجل في نفس هذا التوقيت (${updates.appointmentTime}) للمريض "${patient ? patient.fullName : conflict.patientId}".`,
        };
      }
    }

    const updated: Appointment = {
      ...current,
      ...updates,
      id: current.id,
      clinicId: current.clinicId,
    };

    this.state.appointments[index] = updated;
    this.scheduleSave();
    return { appointment: updated };
  }

  public deleteAppointment(id: string, clinicId?: string): boolean {
    if (!this.state.appointments) return false;
    const initialLen = this.state.appointments.length;
    this.state.appointments = this.state.appointments.filter(a => !(a.id === id && (!clinicId || a.clinicId === clinicId)));
    if (this.state.appointments.length === initialLen) return false;
    this.scheduleSave();
    return true;
  }

  // ================= DENTAL CONDITIONS (SCOPED) =================
  public getDentalConditions(patientId?: string, clinicId?: string): DentalCondition[] {
    let list = this.state.dentalConditions || [];
    if (clinicId) {
      list = list.filter(c => c.clinicId === clinicId);
    }
    if (patientId) {
      list = list.filter(c => c.patientId === patientId);
    }
    return list;
  }

  public createDentalCondition(
    conditionData: Omit<DentalCondition, 'id' | 'createdAt' | 'clinicId'> & { clinicId?: string },
    clinicId?: string
  ): DentalCondition {
    const targetClinicId = clinicId || conditionData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const newCondition: DentalCondition = {
      ...conditionData,
      clinicId: targetClinicId,
      id: `CND-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
    };
    if (!this.state.dentalConditions) this.state.dentalConditions = [];
    this.state.dentalConditions.push(newCondition);
    this.scheduleSave();
    return newCondition;
  }

  public updateDentalCondition(id: string, updates: Partial<DentalCondition>, clinicId?: string): DentalCondition | null {
    if (!this.state.dentalConditions) this.state.dentalConditions = [];
    const index = this.state.dentalConditions.findIndex(c => c.id === id && (!clinicId || c.clinicId === clinicId));
    if (index === -1) return null;

    const current = this.state.dentalConditions[index];
    const updated: DentalCondition = {
      ...current,
      ...updates,
      id: current.id,
      clinicId: current.clinicId,
      updatedAt: new Date().toISOString(),
    };
    this.state.dentalConditions[index] = updated;
    this.scheduleSave();
    return updated;
  }

  public deleteDentalCondition(id: string, clinicId?: string): boolean {
    if (!this.state.dentalConditions) return false;
    const initialLen = this.state.dentalConditions.length;
    this.state.dentalConditions = this.state.dentalConditions.filter(c => !(c.id === id && (!clinicId || c.clinicId === clinicId)));
    if (this.state.dentalConditions.length === initialLen) return false;
    this.scheduleSave();
    return true;
  }

  // ================= CLINICAL NOTES (SCOPED) =================
  public getClinicalNotes(patientId: string, clinicId?: string): ClinicalNote[] {
    let list = this.state.clinicalNotes || [];
    if (clinicId) {
      list = list.filter(n => n.clinicId === clinicId);
    }
    return list.filter(n => n.patientId === patientId);
  }

  public createClinicalNote(
    noteData: Omit<ClinicalNote, 'id' | 'createdAt' | 'clinicId'> & { clinicId?: string },
    clinicId?: string
  ): ClinicalNote {
    const targetClinicId = clinicId || noteData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const newNote: ClinicalNote = {
      ...noteData,
      clinicId: targetClinicId,
      id: `NOT-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
    };
    if (!this.state.clinicalNotes) this.state.clinicalNotes = [];
    this.state.clinicalNotes.push(newNote);
    this.scheduleSave();
    return newNote;
  }

  public deleteClinicalNote(id: string, clinicId?: string): boolean {
    if (!this.state.clinicalNotes) return false;
    const initialLen = this.state.clinicalNotes.length;
    this.state.clinicalNotes = this.state.clinicalNotes.filter(n => !(n.id === id && (!clinicId || n.clinicId === clinicId)));
    if (this.state.clinicalNotes.length === initialLen) return false;
    this.scheduleSave();
    return true;
  }

  // ================= PATIENT FILES (SCOPED) =================
  public getPatientFiles(patientId?: string, clinicId?: string): PatientFile[] {
    let list = this.state.patientFiles || [];
    if (clinicId) {
      list = list.filter(f => f.clinicId === clinicId);
    }
    if (patientId) {
      list = list.filter(f => f.patientId === patientId);
    }
    return list;
  }

  public addPatientFile(
    fileData: Omit<PatientFile, 'id' | 'uploadDate' | 'clinicId'> & { clinicId?: string },
    clinicId?: string
  ): PatientFile {
    const targetClinicId = clinicId || fileData.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const newFile: PatientFile = {
      ...fileData,
      clinicId: targetClinicId,
      id: `FILE-${Date.now().toString().slice(-6)}`,
      uploadDate: new Date().toISOString(),
    };
    if (!this.state.patientFiles) this.state.patientFiles = [];
    this.state.patientFiles.push(newFile);
    this.scheduleSave();
    return newFile;
  }

  public deletePatientFile(id: string, clinicId?: string): boolean {
    if (!this.state.patientFiles) return false;
    const file = this.state.patientFiles.find(f => f.id === id && (!clinicId || f.clinicId === clinicId));
    if (!file) return false;

    if (fs.existsSync(file.filePath)) {
      try {
        fs.unlinkSync(file.filePath);
      } catch (err) {
        console.error('Error deleting physical file:', err);
      }
    }

    this.state.patientFiles = this.state.patientFiles.filter(f => f.id !== id);
    this.scheduleSave();
    return true;
  }

  // ================= DASHBOARD & FINANCIAL STATS (SCOPED) =================
  public getDashboardStats(clinicId: string) {
    const arabicMonths = [
      'جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان',
      'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];

    const patients = this.getPatients(clinicId);
    const appointments = this.getAppointments(clinicId);

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentMonthPrefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    const todayAppointments = appointments.filter(a => a.appointmentDate === todayStr);
    const completedToday = todayAppointments.filter(a => a.status === 'completed').length;
    const scheduledToday = todayAppointments.filter(a => a.status === 'scheduled').length;

    const newPatientsThisMonth = patients.filter(
      p => p.patientType === 'new' && p.createdAt && p.createdAt.startsWith(currentMonthPrefix)
    ).length;

    const totalPatients = patients.length;
    const returningPatients = patients.filter(p => p.patientType === 'returning').length;
    const newPatients = patients.filter(p => p.patientType === 'new').length;

    const upcomingAppointments = appointments
      .filter(a => a.appointmentDate >= todayStr && a.status === 'scheduled')
      .sort((a, b) => (a.appointmentDate + a.appointmentTime).localeCompare(b.appointmentDate + b.appointmentTime))
      .slice(0, 10);

    const monthlyStats = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const count = patients.filter(p => p.createdAt && p.createdAt.startsWith(mStr)).length;
      monthlyStats.push({
        month: mStr,
        monthLabel: arabicMonths[d.getMonth()],
        count,
      });
    }

    const currentYear = now.getFullYear();
    const yearlyStats = [];
    for (let m = 0; m < 12; m++) {
      const monthNum = String(m + 1).padStart(2, '0');
      const prefix = `${currentYear}-${monthNum}`;
      const count = patients.filter(p => p.createdAt && p.createdAt.startsWith(prefix)).length;
      yearlyStats.push({
        month: monthNum,
        monthLabel: arabicMonths[m],
        shortLabel: arabicMonths[m],
        newPatients: count,
        year: currentYear,
      });
    }

    return {
      todayAppointmentsCount: todayAppointments.length,
      todayAppointmentsCompleted: completedToday,
      todayAppointmentsScheduled: scheduledToday,
      newPatientsThisMonth,
      returningPatientsCount: returningPatients,
      newPatientsCount: newPatients,
      totalPatientsCount: totalPatients,
      todayAppointmentsList: todayAppointments.sort((a, b) => a.appointmentTime.localeCompare(b.appointmentTime)),
      upcomingAppointmentsList: upcomingAppointments,
      monthlyDistribution: monthlyStats,
      yearlyDistribution: yearlyStats,
      currentYear,
    };
  }

  public getFinancialStats(clinicId: string) {
    const arabicMonths = [
      'جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان',
      'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    const arabicDays = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

    const appointments = this.getAppointments(clinicId);

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonthPrefix = `${currentYear}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    const getCost = (apt: Appointment): number => {
      if (apt.cost && apt.cost > 0) return apt.cost;
      const p = apt.procedure.toLowerCase();
      if (p.includes('كشف') || p.includes('فحص')) return 1500;
      if (p.includes('تنظيف') || p.includes('جير')) return 3000;
      if (p.includes('حشوة') || p.includes('كمبوزيت')) return 3500;
      if (p.includes('عصب')) return 7000;
      if (p.includes('جذور')) return 8000;
      if (p.includes('قلع')) return 2500;
      if (p.includes('تاج') || p.includes('سيراميك')) return 18000;
      if (p.includes('تبييض')) return 5000;
      if (p.includes('زرع')) return 60000;
      if (p.includes('تقويم')) return 15000;
      return 3500;
    };

    const completedApts = appointments.filter(a => a.status === 'completed');
    const yearCompleted = completedApts.filter(a => a.appointmentDate.startsWith(String(currentYear)));
    const totalRevenueYear = yearCompleted.reduce((sum, a) => sum + getCost(a), 0);

    const monthCompleted = completedApts.filter(a => a.appointmentDate.startsWith(currentMonthPrefix));
    const totalRevenueMonth = monthCompleted.reduce((sum, a) => sum + getCost(a), 0);

    const currentDayOfWeek = now.getDay();
    const daysSinceSaturday = (currentDayOfWeek + 1) % 7;
    const saturday = new Date(now);
    saturday.setDate(now.getDate() - daysSinceSaturday);
    saturday.setHours(0, 0, 0, 0);

    const friday = new Date(saturday);
    friday.setDate(saturday.getDate() + 6);
    friday.setHours(23, 59, 59, 999);

    const saturdayStr = saturday.toISOString().split('T')[0];
    const fridayStr = friday.toISOString().split('T')[0];

    const weekCompleted = completedApts.filter(a =>
      a.appointmentDate >= saturdayStr && a.appointmentDate <= fridayStr
    );
    const totalRevenueWeek = weekCompleted.reduce((sum, a) => sum + getCost(a), 0);

    const monthlyRevenue = [];
    for (let m = 0; m < 12; m++) {
      const monthNum = String(m + 1).padStart(2, '0');
      const prefix = `${currentYear}-${monthNum}`;
      const aptsInMonth = completedApts.filter(a => a.appointmentDate.startsWith(prefix));
      const rev = aptsInMonth.reduce((sum, a) => sum + getCost(a), 0);
      monthlyRevenue.push({
        month: monthNum,
        monthLabel: arabicMonths[m],
        revenue: rev,
        completedCount: aptsInMonth.length,
      });
    }

    const weeklyRevenue = [];
    for (let w = 7; w >= 0; w--) {
      const wStart = new Date(saturday);
      wStart.setDate(saturday.getDate() - (w * 7));
      const wEnd = new Date(wStart);
      wEnd.setDate(wStart.getDate() + 6);

      const wStartStr = wStart.toISOString().split('T')[0];
      const wEndStr = wEnd.toISOString().split('T')[0];

      const aptsInW = completedApts.filter(a => a.appointmentDate >= wStartStr && a.appointmentDate <= wEndStr);
      const rev = aptsInW.reduce((sum, a) => sum + getCost(a), 0);
      const sParts = wStartStr.split('-');

      weeklyRevenue.push({
        weekLabel: w === 0 ? 'هذا الأسبوع' : w === 1 ? 'الأسبوع الماضي' : `أسبوع ${sParts[2]}/${sParts[1]}`,
        weekNumber: 8 - w,
        startDate: wStartStr,
        endDate: wEndStr,
        revenue: rev,
        completedCount: aptsInW.length,
      });
    }

    const dailyRevenueThisWeek = [];
    for (let d = 0; d < 7; d++) {
      const dayDate = new Date(saturday);
      dayDate.setDate(saturday.getDate() + d);
      const dStr = dayDate.toISOString().split('T')[0];
      const aptsOnDay = completedApts.filter(a => a.appointmentDate === dStr);
      const rev = aptsOnDay.reduce((sum, a) => sum + getCost(a), 0);
      dailyRevenueThisWeek.push({
        dayName: arabicDays[dayDate.getDay()],
        date: dStr,
        revenue: rev,
        count: aptsOnDay.length,
      });
    }

    const procMap = new Map<string, { revenue: number; count: number }>();
    for (const a of yearCompleted) {
      const cost = getCost(a);
      const item = procMap.get(a.procedure) || { revenue: 0, count: 0 };
      item.revenue += cost;
      item.count += 1;
      procMap.set(a.procedure, item);
    }

    const procedureBreakdown = Array.from(procMap.entries()).map(([proc, val]) => ({
      procedure: proc,
      revenue: val.revenue,
      count: val.count,
      percentage: totalRevenueYear > 0 ? Math.round((val.revenue / totalRevenueYear) * 100) : 0,
    })).sort((a, b) => b.revenue - a.revenue);

    return {
      totalRevenueYear,
      totalRevenueMonth,
      totalRevenueWeek,
      totalCompletedAppointments: completedApts.length,
      averagePerAppointment: completedApts.length > 0 ? Math.round(totalRevenueYear / (yearCompleted.length || 1)) : 0,
      monthlyRevenue,
      weeklyRevenue,
      dailyRevenueThisWeek,
      procedureBreakdown,
    };
  }

  // ================= BACKUP & RESTORE (SCOPED PER CLINIC) =================
  public async generateBackupZip(clinicId: string): Promise<Buffer> {
    const clinic = this.getClinicById(clinicId) || this.state.clinics?.[0];
    const settings = this.getClinicSettings(clinicId);
    const patients = this.getPatients(clinicId);
    const appointments = this.getAppointments(clinicId);
    const dentalConditions = this.getDentalConditions(undefined, clinicId);
    const clinicalNotes = (this.state.clinicalNotes || []).filter(n => n.clinicId === clinicId);
    const patientFiles = this.getPatientFiles(undefined, clinicId);
    const users = this.getUsers(clinicId).map(u => ({
      ...u,
      passwordHash: u.passwordHash,
      salt: u.salt,
    }));

    const scopedDb = {
      clinic,
      users,
      patients,
      appointments,
      dentalConditions,
      clinicalNotes,
      patientFiles,
    };

    const zip = new JSZip();
    zip.file('clinic_database.json', JSON.stringify(scopedDb, null, 2));

    const backupReadme = `نسخة احتياطية لعيادة طب الأسنان
اسم العيادة: ${settings.clinicName}
معرف العيادة: ${clinicId}
الطبيب المدير: ${settings.doctorName}
تاريخ الإنشاء: ${new Date().toLocaleString('ar-DZ')}
عدد المرضى: ${patients.length}
عدد المواعيد: ${appointments.length}
عدد ملفات الأشعة: ${patientFiles.length}
`;
    zip.file('معلومات_النسخة.txt', backupReadme);

    const filesFolder = zip.folder('patient_files');
    if (filesFolder) {
      for (const fileRecord of patientFiles) {
        if (fs.existsSync(fileRecord.filePath)) {
          const patient = this.getPatientById(fileRecord.patientId, clinicId);
          const patientFolderName = patient
            ? `${sanitizeFolderName(patient.fullName)}_${patient.id}`
            : `Patient_${fileRecord.patientId}`;
          const content = fs.readFileSync(fileRecord.filePath);
          filesFolder.file(`${patientFolderName}/${fileRecord.originalName}`, content);
        }
      }
    }

    return await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });
  }

  public async restoreFromZip(zipBuffer: Buffer, clinicId: string): Promise<{ success: boolean; message: string }> {
    try {
      const zip = await JSZip.loadAsync(zipBuffer);
      const dbEntry = zip.file('clinic_database.json');
      if (!dbEntry) {
        return { success: false, message: 'الملف لا يحتوي على قاعدة بيانات clinic_database.json صحيحة.' };
      }
      const dbContent = await dbEntry.async('string');
      const parsed: any = JSON.parse(dbContent);

      if (!Array.isArray(parsed.patients) || !Array.isArray(parsed.appointments)) {
        return { success: false, message: 'هيكل ملف قاعدة البيانات غير متوافق.' };
      }

      // Purge existing data for this clinic only
      this.state.patients = (this.state.patients || []).filter(p => p.clinicId !== clinicId);
      this.state.appointments = (this.state.appointments || []).filter(a => a.clinicId !== clinicId);
      this.state.dentalConditions = (this.state.dentalConditions || []).filter(c => c.clinicId !== clinicId);
      this.state.clinicalNotes = (this.state.clinicalNotes || []).filter(n => n.clinicId !== clinicId);
      this.state.patientFiles = (this.state.patientFiles || []).filter(f => f.clinicId !== clinicId);

      // Re-insert imported records with current clinicId
      for (const p of parsed.patients) {
        this.state.patients.push({ ...p, clinicId });
      }
      for (const a of parsed.appointments) {
        this.state.appointments.push({ ...a, clinicId });
      }
      for (const c of (parsed.dentalConditions || [])) {
        this.state.dentalConditions.push({ ...c, clinicId });
      }
      for (const n of (parsed.clinicalNotes || [])) {
        this.state.clinicalNotes.push({ ...n, clinicId });
      }

      // Restore files
      const storagePath = this.getStoragePath(clinicId);
      const filesInZip = Object.keys(zip.files).filter(k => k.startsWith('patient_files/') && !zip.files[k].dir);

      for (const relativePath of filesInZip) {
        const fileData = await zip.files[relativePath].async('nodebuffer');
        const targetDiskPath = path.join(storagePath, `clinic_${clinicId}`, relativePath.replace('patient_files/', ''));
        const targetDir = path.dirname(targetDiskPath);
        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        fs.writeFileSync(targetDiskPath, fileData);
      }

      for (const f of (parsed.patientFiles || [])) {
        this.state.patientFiles.push({
          ...f,
          clinicId,
          filePath: path.join(storagePath, `clinic_${clinicId}`, f.storedName || path.basename(f.filePath)),
        });
      }

      if (parsed.clinic) {
        this.updateClinicSettings(clinicId, parsed.clinic);
      }

      this.scheduleSave();
      return { success: true, message: 'تمت استعادة بيانات العيادة بنجاح وتحديث كافة السجلات.' };
    } catch (err: any) {
      console.error('Error during restore:', err);
      return { success: false, message: `فشل استعادة النسخة: ${err.message || 'خطأ غير معروف'}` };
    }
  }

  // ================= SMS =================
  private formatSmsTemplate(template: string, vars: Record<string, string>): string {
    let result = template;
    for (const [key, val] of Object.entries(vars)) {
      result = result.replace(new RegExp(`\\{${key}\\}`, 'g'), val || '');
    }
    return result;
  }

  public async sendSms(
    phone: string,
    message: string,
    meta?: { appointmentId?: string; patientId?: string; patientName?: string; clinicId?: string }
  ): Promise<{ success: boolean; log: SmsLog; message: string }> {
    const targetClinicId = meta?.clinicId || this.state.clinics?.[0]?.id || 'cln-default';
    const settings = this.getClinicSettings(targetClinicId);
    const logId = `SMS-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();
    const cleanPhone = phone.replace(/\s+/g, '');

    const newLog: SmsLog = {
      id: logId,
      clinicId: targetClinicId,
      appointmentId: meta?.appointmentId,
      patientId: meta?.patientId,
      patientName: meta?.patientName || 'مريض',
      phone: cleanPhone,
      message,
      status: 'simulated',
      provider: settings.smsProvider || 'local_simulator',
      sentAt: now,
    };

    if (!this.state.smsLogs) this.state.smsLogs = [];
    this.state.smsLogs.unshift(newLog);
    if (this.state.smsLogs.length > 200) {
      this.state.smsLogs = this.state.smsLogs.slice(0, 200);
    }
    this.scheduleSave();

    return {
      success: true,
      log: newLog,
      message: 'تم إرسال تذكير الموعد وحفظه بنجاح.',
    };
  }

  public async sendAppointmentReminderSms(appointmentId: string, clinicId?: string): Promise<{ success: boolean; log?: SmsLog; message: string }> {
    const apt = (this.state.appointments || []).find(a => a.id === appointmentId && (!clinicId || a.clinicId === clinicId));
    if (!apt) {
      return { success: false, message: 'الموعد غير موجود' };
    }
    const patient = this.getPatientById(apt.patientId, apt.clinicId);
    if (!patient || !patient.phone) {
      return { success: false, message: 'المريض ليس لديه رقم هاتف مسجل' };
    }

    const settings = this.getClinicSettings(apt.clinicId);
    const template = settings.smsReminderTemplate || DEFAULT_SMS_REMINDER_TEMPLATE;
    const parts = apt.appointmentDate.split('-');
    const dateFormatted = parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : apt.appointmentDate;

    const message = this.formatSmsTemplate(template, {
      patientName: patient.fullName,
      clinicName: settings.clinicName || 'عيادة الأسنان',
      date: dateFormatted,
      time: apt.appointmentTime,
      doctorName: settings.doctorName || 'طبيب العيادة',
      procedure: apt.procedure || 'كشف',
      phone: settings.phone || '',
    });

    const res = await this.sendSms(patient.phone, message, {
      appointmentId: apt.id,
      patientId: patient.id,
      patientName: patient.fullName,
      clinicId: apt.clinicId,
    });

    if (res.success) {
      apt.smsReminderSent = true;
      apt.smsReminderSentAt = new Date().toISOString();
      this.scheduleSave();
    }

    return res;
  }

  public async checkAndSend24hReminders(clinicId?: string): Promise<{ sentCount: number; logs: SmsLog[] }> {
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    const eligibleApts = (this.state.appointments || []).filter(a => {
      if (clinicId && a.clinicId !== clinicId) return false;
      if (a.status !== 'scheduled') return false;
      if (a.smsReminderSent) return false;
      return a.appointmentDate === tomorrowStr;
    });

    const sentLogs: SmsLog[] = [];
    for (const apt of eligibleApts) {
      const res = await this.sendAppointmentReminderSms(apt.id, apt.clinicId);
      if (res.success && res.log) {
        sentLogs.push(res.log);
      }
    }

    return {
      sentCount: sentLogs.length,
      logs: sentLogs,
    };
  }

  public getSmsLogs(clinicId?: string): SmsLog[] {
    const logs = this.state.smsLogs || [];
    if (!clinicId) return logs;
    return logs.filter(l => l.clinicId === clinicId);
  }
}

export const clinicDb = new ClinicDatabase();
