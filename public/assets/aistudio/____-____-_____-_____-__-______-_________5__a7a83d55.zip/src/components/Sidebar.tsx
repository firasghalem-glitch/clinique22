import React from 'react';
import { User, ClinicSettings } from '../types';
import {
  LayoutDashboard,
  Calendar,
  Users,
  Activity,
  Smile,
  Receipt,
  Shield,
  Settings,
  BookOpen,
  Download,
  LogOut,
  X,
  Stethoscope,
  ChevronLeft,
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  onQuickBackup: () => void;
  settings: ClinicSettings;
  todayCount: number;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  currentUser,
  onLogout,
  onQuickBackup,
  settings,
  todayCount,
  isOpen,
  onClose,
}) => {
  const isDoctor = currentUser?.role === 'doctor';

  // Automatically select the chosen page and immediately close the sidebar
  const handleSelectTab = (tab: string) => {
    setCurrentTab(tab);
    onClose();
  };

  const clinicalNavItems = [
    {
      id: 'dashboard',
      label: 'لوحة التحكم',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'appointments',
      label: 'المواعيد',
      icon: Calendar,
      badge: todayCount > 0 ? `${todayCount} اليوم` : null,
      badgeColor: 'bg-teal-100 text-teal-800',
    },
    {
      id: 'patients',
      label: 'المرضى',
      icon: Users,
      badge: null,
    },
    {
      id: 'conditions',
      label: 'حالات الأسنان',
      icon: Activity,
      badge: null,
    },
    {
      id: 'jaw-chart',
      label: 'مخطط الفك والأسنان',
      icon: Smile,
      badge: 'تفاعلي',
      badgeColor: 'bg-teal-100 text-teal-800',
    },
  ];

  const adminNavItems = isDoctor
    ? [
        {
          id: 'finance',
          label: 'المالية والفواتير',
          icon: Receipt,
        },
        {
          id: 'users',
          label: 'إدارة الفريق والموظفين',
          icon: Shield,
        },
        {
          id: 'settings',
          label: 'الإعدادات والنسخ',
          icon: Settings,
        },
      ]
    : [];

  const helpNavItems = [
    {
      id: 'guide',
      label: 'دليل الاستخدام',
      icon: BookOpen,
    },
  ];

  return (
    <>
      {/* Backdrop Overlay: Closes sidebar on click */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in"
          title="انقر لإغلاق القائمة"
        />
      )}

      {/* Slide-out Sidebar Drawer on the Right */}
      <aside
        className={`fixed inset-y-0 right-0 z-50 w-72 sm:w-80 bg-white border-l border-slate-200 flex flex-col shadow-2xl transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        aria-hidden={!isOpen}
      >
        {/* Brand & Clinic Info Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between gap-3 bg-gradient-to-b from-teal-50/60 to-white">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-lg shadow-sm shrink-0">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12 2C7.5 2 4 4.5 4 8c0 2.2 1.5 5.5 3 9.5.8 2.1 1.7 4.5 2.5 4.5s1.5-2 2.5-4c1-2 2-2 2-2s1 0 2 2c1 2 1.7 4 2.5 4s1.7-2.4 2.5-4.5c1.5-4 3-7.3 3-9.5 0-3.5-3.5-6-8-6zm0 2c3.5 0 6 1.8 6 4 0 1.7-1.3 4.6-2.6 8.1-.5 1.4-1.1 2.9-1.4 3.4-.6-1-1.3-1.8-2-1.8s-1.4.8-2 1.8c-.3-.5-.9-2-1.4-3.4C7.3 12.6 6 9.7 6 8c0-2.2 2.5-4 6-4z" />
              </svg>
            </div>
            <div className="min-w-0">
              <button
                type="button"
                onClick={() => handleSelectTab('dashboard')}
                className="text-sm sm:text-base font-extrabold text-slate-900 font-heading tracking-tight truncate block text-right hover:text-teal-700 transition-colors cursor-pointer w-full"
                title={currentUser?.clinicName || settings.clinicName || 'عيادة طب وجراحة الأسنان'}
              >
                {currentUser?.clinicName || settings.clinicName || 'عيادة طب وجراحة الأسنان'}
              </button>
              <div className="text-[11px] text-slate-500 font-medium truncate flex items-center gap-1.5 mt-0.5">
                <span className="font-semibold text-slate-700">{currentUser?.fullName || settings.doctorName || 'د. المشرف'}</span>
                <span className="text-slate-300">•</span>
                <span className="text-teal-700 font-bold">طب الأسنان</span>
              </div>
            </div>
          </div>

          {/* Close button (X) */}
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
            title="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs Area */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
          {/* Group 1: Clinical Sections */}
          <div>
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-heading">
              الأقسام السريرية
            </div>
            <nav className="space-y-1">
              {clinicalNavItems.map(item => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right group ${
                      isActive
                        ? 'bg-teal-600 text-white shadow-xs font-bold'
                        : 'text-slate-700 hover:bg-teal-50/80 hover:text-teal-900'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-white' : 'text-teal-600'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.badge && (
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono ${
                            isActive ? 'bg-white/20 text-white' : item.badgeColor
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {isActive && <ChevronLeft className="w-3.5 h-3.5 text-white/80" />}
                    </div>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Group 2: Management & Finance (Doctor Only) */}
          {adminNavItems.length > 0 && (
            <div>
              <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-heading flex items-center justify-between">
                <span>الإدارة والمالية</span>
                <span className="text-[9px] bg-amber-50 text-amber-700 px-1.5 py-0.2 rounded border border-amber-200">
                  خاص بالطبيب
                </span>
              </div>
              <nav className="space-y-1">
                {adminNavItems.map(item => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectTab(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right group ${
                        isActive
                          ? 'bg-teal-600 text-white shadow-xs font-bold'
                          : 'text-slate-700 hover:bg-teal-50/80 hover:text-teal-900'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <Icon
                          className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                            isActive ? 'text-white' : 'text-teal-600'
                          }`}
                        />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {isActive && <ChevronLeft className="w-3.5 h-3.5 text-white/80" />}
                    </button>
                  );
                })}
              </nav>
            </div>
          )}

          {/* Group 3: Help & Documentation */}
          <div>
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-heading">
              المساعدة والتوثيق
            </div>
            <nav className="space-y-1">
              {helpNavItems.map(item => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-right group ${
                      isActive
                        ? 'bg-teal-600 text-white shadow-xs font-bold'
                        : 'text-slate-700 hover:bg-teal-50/80 hover:text-teal-900'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-white' : 'text-teal-600'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {isActive && <ChevronLeft className="w-3.5 h-3.5 text-white/80" />}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Quick Doctor Backup CTA */}
          {isDoctor && (
            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  onQuickBackup();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-gradient-to-r from-teal-50 to-emerald-50 hover:from-teal-100 hover:to-emerald-100 text-teal-800 border border-teal-200/80 rounded-xl text-xs font-bold transition-all shadow-2xs cursor-pointer"
                title="تصدير نسخة احتياطية كاملة من قاعدة بيانات العيادة والملفات"
              >
                <Download className="w-4 h-4 text-teal-700" />
                <span>نسخ احتياطي سريع (ZIP)</span>
              </button>
            </div>
          )}
        </div>

        {/* User Card & Logout Footer */}
        {currentUser && (
          <div className="p-3 border-t border-slate-200 bg-slate-50/90">
            <div className="flex items-center justify-between gap-2.5 bg-white p-2.5 rounded-xl border border-slate-200">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs shrink-0 border border-teal-200">
                  <Stethoscope className="w-4 h-4 text-teal-700" />
                </div>
                <div className="min-w-0 text-right">
                  <div className="text-xs font-bold text-slate-800 truncate font-heading">
                    {currentUser.fullName}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                    <span className="text-teal-700 font-bold">
                      {currentUser.role === 'doctor' ? 'مدير العيادة (طبيب)' : 'موظف عيادة (مساعد)'}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="text-slate-400 truncate">@{currentUser.username}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                title="تسجيل الخروج من الجلسة"
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
