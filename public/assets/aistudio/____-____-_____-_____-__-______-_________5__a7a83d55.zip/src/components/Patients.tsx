import React, { useState, useRef, useEffect } from 'react';
import {
  Patient,
  PatientFile,
  DentalCondition,
  Appointment,
  ClinicalNote,
  ClinicSettings
} from '../types';
import { clinicApi } from '../services/api';
import { localPatientStorageService } from '../utils/localPatientStorage';
import {
  Users,
  UserPlus,
  Search,
  Phone,
  AlertTriangle,
  Edit3,
  Trash2,
  FileText,
  Check,
  HeartPulse,
  Upload,
  Image as ImageIcon,
  X,
  Download,
  HardDrive,
  ChevronDown,
  Smile,
} from 'lucide-react';

interface PendingPhoto {
  id: string;
  file: File;
  previewUrl: string;
  category: string;
}

const PHOTO_CATEGORIES = [
  { id: 'صورة أشعة بانورامية (Panoramique)', label: 'صورة أشعة بانورامية (Panoramique)' },
  { id: 'أشعة سينية داخل فموية (Radio RVG)', label: 'أشعة سينية داخل فموية (Radio RVG)' },
  { id: 'صورة فوتوغرافية سريرية (Photo clinique)', label: 'صورة فوتوغرافية سريرية' },
  { id: 'تحاليل مخبرية', label: 'تحاليل مخبرية' },
  { id: 'تقرير طبي', label: 'تقرير طبي' },
  { id: 'ملف مرفق عام (Autre)', label: 'ملف مرفق عام' },
];

export const DENTAL_DISEASE_CONDITIONS = [
  { id: 'all', label: 'الكل (جميع الحالات السريرية)', keyword: '', badge: '' },
  { id: 'caries', label: 'علاج تسوس الأسنان', keyword: 'تسوس', badge: 'bg-teal-50 text-teal-800 border-teal-200' },
  { id: 'endodontics', label: 'علاج الجذور والعصب (Endo)', keyword: 'عصب', badge: 'bg-purple-50 text-purple-800 border-purple-200' },
  { id: 'periodontics', label: 'علاج اللثة وجراحة الأنسجة', keyword: 'لثة', badge: 'bg-amber-50 text-amber-900 border-amber-200' },
  { id: 'orthodontics', label: 'تقويم وتعديل الأسنان', keyword: 'تقويم', badge: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
  { id: 'implants', label: 'زرع وتعويض الأسنان', keyword: 'زرع', badge: 'bg-sky-50 text-sky-800 border-sky-200' },
  { id: 'surgery', label: 'جراحة الفم والفكين', keyword: 'جراحة', badge: 'bg-slate-100 text-slate-800 border-slate-300' },
  { id: 'cosmetic', label: 'تجميل الأسنان والفينير', keyword: 'تجميل', badge: 'bg-teal-50 text-teal-800 border-teal-200' },
  { id: 'prophylaxis', label: 'تنظيف الجير والعناية الوقائية', keyword: 'تنظيف', badge: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
  { id: 'urgent', label: 'حالات إسعافية وألم حاد', keyword: 'ألم', badge: 'bg-amber-50 text-amber-900 border-amber-200' },
  { id: 'healthy', label: 'فحص دوري وأسنان سليمة', keyword: 'سليم', badge: 'bg-cyan-50 text-cyan-800 border-cyan-200' },
];

export const getDiseaseBadgeStyle = (conditionText?: string) => {
  if (!conditionText) return 'bg-slate-50 text-slate-700 border-slate-200';
  if (conditionText.includes('عصب') || conditionText.includes('جذور')) {
    return 'bg-purple-50 text-purple-800 border-purple-200';
  }
  if (conditionText.includes('ألم') || conditionText.includes('خراج') || conditionText.includes('إسعافي')) {
    return 'bg-amber-50 text-amber-900 border-amber-200';
  }
  if (conditionText.includes('تسوس') || conditionText.includes('حشوة') || conditionText.includes('كمبوزيت')) {
    return 'bg-teal-50 text-teal-800 border-teal-200';
  }
  if (conditionText.includes('لثة') || conditionText.includes('نزيف')) {
    return 'bg-amber-50 text-amber-900 border-amber-200';
  }
  if (conditionText.includes('تقويم')) {
    return 'bg-indigo-50 text-indigo-800 border-indigo-200';
  }
  if (conditionText.includes('زرع') || conditionText.includes('غرس') || conditionText.includes('تاج')) {
    return 'bg-sky-50 text-sky-800 border-sky-200';
  }
  if (conditionText.includes('قلع') || conditionText.includes('جراحة')) {
    return 'bg-slate-100 text-slate-800 border-slate-300';
  }
  if (conditionText.includes('تجميل') || conditionText.includes('فينير') || conditionText.includes('تبييض')) {
    return 'bg-teal-50 text-teal-800 border-teal-200';
  }
  if (conditionText.includes('سليم') || conditionText.includes('وقائي') || conditionText.includes('تنظيف')) {
    return 'bg-emerald-50 text-emerald-800 border-emerald-200';
  }
  return 'bg-teal-50 text-teal-800 border-teal-200';
};

interface PatientsProps {
  patients: Patient[];
  files?: PatientFile[];
  conditions?: DentalCondition[];
  appointments?: Appointment[];
  notes?: ClinicalNote[];
  settings?: ClinicSettings;
  onAddPatient: (patient: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Patient>;
  onUpdatePatient: (id: string, updates: Partial<Patient>) => Promise<Patient>;
  onDeletePatient: (id: string) => Promise<void>;
  onOpenPatientDossier: (patientId: string, initialTab?: 'profile' | 'medical' | 'teeth' | 'jaw-chart' | 'appointments' | 'treatments' | 'files' | 'invoices' | 'notes') => void;
  onBookAppointmentForPatient: (patientId: string) => void;
  onRefreshFiles?: () => Promise<void> | void;
  onShowToast?: (message: string) => void;
  currentUserRole?: 'doctor' | 'assistant';
}

export const Patients: React.FC<PatientsProps> = ({
  patients,
  files = [],
  conditions = [],
  appointments = [],
  notes: clinicalNotesList = [],
  settings,
  onAddPatient,
  onUpdatePatient,
  onDeletePatient,
  onOpenPatientDossier,
  onBookAppointmentForPatient,
  onRefreshFiles,
  onShowToast,
  currentUserRole = 'doctor',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'new' | 'returning'>('all');
  const [diseaseFilter, setDiseaseFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [address, setAddress] = useState('');
  const [allergies, setAllergies] = useState('');
  const [patientType, setPatientType] = useState<'new' | 'returning'>('new');
  const [diseaseCondition, setDiseaseCondition] = useState('');
  const [diseaseStatus, setDiseaseStatus] = useState<'active' | 'under_treatment' | 'completed' | 'stable' | 'urgent'>('active');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [savingPatientId, setSavingPatientId] = useState<string | null>(null);
  const [quickConditionPatient, setQuickConditionPatient] = useState<Patient | null>(null);
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null);
  const [isDeletingPatient, setIsDeletingPatient] = useState(false);

  const [isDiseaseDropdownOpen, setIsDiseaseDropdownOpen] = useState(false);
  const diseaseDropdownRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (diseaseDropdownRef.current && !diseaseDropdownRef.current.contains(event.target as Node)) {
        setIsDiseaseDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const [selectedPhotos, setSelectedPhotos] = useState<PendingPhoto[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const calculateAge = (bDate: string) => {
    if (!bDate) return null;
    const birth = new Date(bDate);
    const now = new Date();
    let age = now.getFullYear() - birth.getFullYear();
    const m = now.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) {
      age--;
    }
    return age >= 0 ? age : null;
  };

  const formatDateDZ = (dateStr: string) => {
    if (!dateStr) return '-';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  const handleClearPhotos = () => {
    selectedPhotos.forEach(p => {
      if (p.previewUrl) URL.revokeObjectURL(p.previewUrl);
    });
    setSelectedPhotos([]);
  };

  const handleSelectPhotos = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const newPhotos: PendingPhoto[] = [];
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const previewUrl = file.type.startsWith('image/')
        ? URL.createObjectURL(file)
        : '';
      newPhotos.push({
        id: `p-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 7)}`,
        file,
        previewUrl,
        category: 'صورة أشعة بانورامية (Panoramique)',
      });
    }
    setSelectedPhotos(prev => [...prev, ...newPhotos]);
    e.target.value = '';
  };

  const handleRemovePhoto = (index: number) => {
    setSelectedPhotos(prev => {
      const target = prev[index];
      if (target?.previewUrl) {
        URL.revokeObjectURL(target.previewUrl);
      }
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleUpdatePhotoCategory = (index: number, newCat: string) => {
    setSelectedPhotos(prev => {
      const updated = [...prev];
      if (updated[index]) {
        updated[index] = { ...updated[index], category: newCat };
      }
      return updated;
    });
  };

  const handleOpenAdd = () => {
    handleClearPhotos();
    setEditingPatient(null);
    setFullName('');
    setPhone('');
    setBirthDate('');
    setGender('male');
    setAddress('');
    setAllergies('');
    setPatientType('new');
    setDiseaseCondition('علاج تسوس الأسنان');
    setDiseaseStatus('active');
    setNotes('');
    setFormError(null);
    setIsDiseaseDropdownOpen(false);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Patient) => {
    handleClearPhotos();
    setEditingPatient(p);
    setFullName(p.fullName);
    setPhone(p.phone);
    setBirthDate(p.birthDate || '');
    setGender(p.gender);
    setAddress(p.address || '');
    setAllergies(p.allergies || '');
    setPatientType(p.patientType);
    setDiseaseCondition(p.diseaseCondition || '');
    setDiseaseStatus(p.diseaseStatus || 'active');
    setNotes(p.notes || '');
    setFormError(null);
    setIsDiseaseDropdownOpen(false);
    setIsModalOpen(true);
  };

  const addAllergyTag = (tag: string) => {
    if (!allergies) {
      setAllergies(tag);
    } else if (!allergies.includes(tag)) {
      setAllergies(`${allergies} • ${tag}`);
    }
  };

  const handleSavePatientLocally = async (p: Patient) => {
    setSavingPatientId(p.id);
    try {
      const ptConditions = conditions.filter(c => c.patientId === p.id);
      const ptNotes = clinicalNotesList.filter(n => n.patientId === p.id);
      const ptApts = appointments.filter(a => a.patientId === p.id);
      const ptFiles = files.filter(f => f.patientId === p.id);
      await localPatientStorageService.savePatientFileLocally(
        p,
        ptConditions,
        ptNotes,
        ptApts,
        ptFiles,
        settings
      );
      if (onShowToast) {
        onShowToast(`تم حفظ وتنزيل ملف المريض "${p.fullName}" محلياً على جهازك.`);
      }
    } catch (err: any) {
      if (onShowToast) onShowToast(`خطأ في الحفظ: ${err.message}`);
    } finally {
      setSavingPatientId(null);
    }
  };

  const handleSaveQuickCondition = async (patient: Patient, newCondition: string) => {
    try {
      await onUpdatePatient(patient.id, {
        diseaseCondition: newCondition,
      });
      if (onShowToast) {
        onShowToast(`تم تحديث تصنيف المريض "${patient.fullName}": ${newCondition}`);
      }
      setQuickConditionPatient(null);
    } catch (err: any) {
      alert('خطأ أثناء التحديث: ' + (err.message || ''));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!fullName.trim()) {
      setFormError('يرجى إدخال اسم المريض كاملاً.');
      return;
    }

    const cleanPhone = phone.replace(/[\s-]/g, '');
    const dzPhoneRegex = /^(05|06|07)[0-9]{8}$/;
    if (!dzPhoneRegex.test(cleanPhone)) {
      setFormError('يرجى إدخال رقم هاتف جزائري صحيح يبدأ بـ 05 أو 06 أو 07 متبوعاً بـ 8 أرقام (10 أرقام إجمالاً).');
      return;
    }

    setIsSubmitting(true);
    try {
      let targetPatient: Patient;
      if (editingPatient) {
        targetPatient = await onUpdatePatient(editingPatient.id, {
          fullName: fullName.trim(),
          phone: cleanPhone,
          birthDate,
          gender,
          address: address.trim(),
          allergies: allergies.trim(),
          patientType,
          diseaseCondition: diseaseCondition.trim() || undefined,
          diseaseStatus,
          notes: notes.trim(),
        });
      } else {
        targetPatient = await onAddPatient({
          fullName: fullName.trim(),
          phone: cleanPhone,
          birthDate,
          gender,
          address: address.trim(),
          allergies: allergies.trim(),
          patientType,
          diseaseCondition: diseaseCondition.trim() || undefined,
          diseaseStatus,
          notes: notes.trim(),
        });
      }

      if (selectedPhotos.length > 0 && targetPatient?.id) {
        for (const photo of selectedPhotos) {
          try {
            await clinicApi.uploadFile(targetPatient.id, photo.file, photo.category);
          } catch (uploadErr) {
            console.error('Failed to upload patient file:', uploadErr);
          }
        }
        if (onRefreshFiles) {
          await onRefreshFiles();
        }
      }

      // Automatically store and save patient file locally on user's device
      try {
        const ptConditions = conditions.filter(c => c.patientId === targetPatient.id);
        const ptNotes = clinicalNotesList.filter(n => n.patientId === targetPatient.id);
        const ptApts = appointments.filter(a => a.patientId === targetPatient.id);
        const ptFiles = files.filter(f => f.patientId === targetPatient.id);
        await localPatientStorageService.savePatientFileLocally(
          targetPatient,
          ptConditions,
          ptNotes,
          ptApts,
          ptFiles,
          settings
        );
        if (onShowToast) {
          onShowToast(`تم حفظ وتحديث ملف المريض (${targetPatient.fullName}) بنجاح`);
        }
      } catch (localSaveErr) {
        console.warn('Auto local save failed:', localSaveErr);
      }

      handleClearPhotos();
      setIsModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'حدث خطأ أثناء حفظ بيانات المريض.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredPatients = patients.filter(p => {
    if (typeFilter !== 'all' && p.patientType !== typeFilter) {
      return false;
    }
    if (diseaseFilter !== 'all') {
      const selected = DENTAL_DISEASE_CONDITIONS.find(c => c.id === diseaseFilter);
      const kw = selected ? selected.keyword : diseaseFilter;
      const matchPatientCond = p.diseaseCondition && p.diseaseCondition.includes(kw);
      const matchDentalChart = conditions.some(c =>
        c.patientId === p.id && (c.conditionType.includes(kw) || (c.diagnosis && c.diagnosis.includes(kw)))
      );
      if (!matchPatientCond && !matchDentalChart) {
        return false;
      }
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        p.fullName.toLowerCase().includes(q) ||
        p.phone.includes(q) ||
        p.id.toLowerCase().includes(q) ||
        (p.diseaseCondition && p.diseaseCondition.toLowerCase().includes(q)) ||
        (p.address && p.address.toLowerCase().includes(q)) ||
        (p.allergies && p.allergies.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-teal-700 shadow-2xs shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-heading tracking-tight">
                سجل وسجلات المرضى
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100/80 text-teal-800 font-heading tabular-nums">
                {patients.length} مريض
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 font-sans leading-relaxed">
              إدارة ملفات المرضى، البيانات الشخصية، السوابق المرضية والحساسية، والصور الشعاعية
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold font-heading rounded-lg shadow-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>إضافة مريض جديد</span>
          </button>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {/* Filter Toolbar */}
        <div className="p-4 border-b border-slate-100 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-slate-50/50">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بالاسم، الهاتف (05/06/07) أو العنوان..."
                className="w-full pr-9 pl-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Disease Filter */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border-2 border-teal-300 hover:border-teal-400 rounded-xl shadow-2xs transition-colors">
                <HeartPulse className="w-4 h-4 text-teal-600 shrink-0" />
                <span className="text-xs font-extrabold font-heading text-slate-800 whitespace-nowrap">
                  تصنيف الحالة:
                </span>
                <select
                  value={diseaseFilter}
                  onChange={(e) => setDiseaseFilter(e.target.value)}
                  className="bg-transparent text-xs font-bold text-teal-900 focus:outline-none cursor-pointer pr-1"
                >
                  {DENTAL_DISEASE_CONDITIONS.map(cond => (
                    <option key={cond.id} value={cond.id}>
                      {cond.label}
                    </option>
                  ))}
                </select>
              </div>
              {diseaseFilter !== 'all' && (
                <button
                  type="button"
                  onClick={() => setDiseaseFilter('all')}
                  className="text-xs text-teal-800 hover:text-teal-950 bg-teal-100 hover:bg-teal-200 px-2.5 py-1.5 rounded-lg font-bold transition-colors flex items-center gap-1 border border-teal-300 shadow-2xs cursor-pointer"
                  title="إلغاء الفلترة"
                >
                  <span>عرض الكل ({patients.length})</span>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1 self-start lg:self-auto shrink-0">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'all'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              الكل ({patients.length})
            </button>
            <button
              onClick={() => setTypeFilter('new')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'new'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              مرضى جدد ({patients.filter(p => p.patientType === 'new').length})
            </button>
            <button
              onClick={() => setTypeFilter('returning')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'returning'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              مرضى متابعون ({patients.filter(p => p.patientType === 'returning').length})
            </button>
          </div>
        </div>

        {/* Patients Table */}
        {filteredPatients.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <Users className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium">لم يتم العثور على أي مريض مطابق للبحث</p>
            <p className="text-xs text-slate-400 mt-1">جرّب تغيير عبارة البحث أو الفلتر أعلاه</p>
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-teal-600 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              + إضافة مريض الآن
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/90 text-slate-700 font-heading font-bold border-b border-slate-200 text-xs">
                <tr>
                  <th className="py-3 px-4 font-bold font-heading">رقم الملف</th>
                  <th className="py-3 px-4 font-bold font-heading">اسم المريض</th>
                  <th className="py-3 px-4 font-bold font-heading">الحالة السريرية</th>
                  <th className="py-3 px-4 font-bold font-heading">رقم الهاتف</th>
                  <th className="py-3 px-4 font-bold font-heading">العمر / الجنس</th>
                  <th className="py-3 px-4 font-bold font-heading">العنوان</th>
                  <th className="py-3 px-4 font-bold font-heading">الحساسية والمحاذير</th>
                  <th className="py-3 px-4 font-bold font-heading">النوع</th>
                  <th className="py-3 px-4 text-center font-bold font-heading">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPatients.map(patient => {
                  const age = calculateAge(patient.birthDate);
                  const hasAlert = patient.allergies && patient.allergies !== 'لا يوجد';
                  const patientFiles = files.filter(f => f.patientId === patient.id);
                  const patientFilesCount = patientFiles.length;

                  return (
                    <tr key={patient.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-500 tabular-nums">
                        {patient.id}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => onOpenPatientDossier(patient.id)}
                          className="font-bold text-teal-800 hover:text-teal-950 hover:underline block text-right font-heading cursor-pointer"
                        >
                          {patient.fullName}
                        </button>
                        <div className="flex items-center gap-2 flex-wrap mt-0.5">
                          <span className="text-[10px] text-slate-400">
                            تاريخ التسجيل: {formatDateDZ(patient.createdAt.slice(0, 10))}
                          </span>
                          {patientFilesCount > 0 && (
                            <button
                              type="button"
                              onClick={() => onOpenPatientDossier(patient.id, 'files')}
                              className="inline-flex items-center gap-1 text-[10px] font-bold text-teal-700 bg-teal-50 border border-teal-200/80 px-2 py-0.5 rounded cursor-pointer hover:bg-teal-600 hover:text-white transition-colors"
                              title="عرض صور وأشعة المريض"
                            >
                              <ImageIcon className="w-3 h-3" />
                              <span>{patientFilesCount} {patientFilesCount === 1 ? 'صورة/أشعة' : 'صور/أشعة'}</span>
                            </button>
                          )}
                        </div>
                      </td>

                      {/* Disease Condition */}
                      <td className="py-3 px-4">
                        {patient.diseaseCondition ? (
                          <button
                            type="button"
                            onClick={() => setQuickConditionPatient(patient)}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border shadow-2xs hover:scale-105 transition-transform cursor-pointer ${getDiseaseBadgeStyle(patient.diseaseCondition)}`}
                            title="انقر لتعديل التشخيص السريري"
                          >
                            <HeartPulse className="w-3.5 h-3.5 shrink-0" />
                            <span>{patient.diseaseCondition}</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setQuickConditionPatient(patient)}
                            className="inline-flex items-center gap-1 text-[11px] text-teal-700 bg-teal-50 hover:bg-teal-100 border border-dashed border-teal-300 px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer"
                            title="إضافة تشخيص سريري للمريض"
                          >
                            <HeartPulse className="w-3 h-3 text-teal-600" />
                            <span>+ تصنيف الحالة</span>
                          </button>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono tabular-nums">
                        <a
                          href={`tel:${patient.phone}`}
                          className="flex items-center gap-1 text-slate-700 hover:text-teal-600"
                          title="اتصال هاتفي"
                        >
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{patient.phone}</span>
                        </a>
                      </td>

                      <td className="py-3 px-4 text-slate-600">
                        {age !== null ? `${age} سنة` : '-'} • {patient.gender === 'male' ? 'ذكر' : 'أنثى'}
                      </td>

                      <td className="py-3 px-4 text-slate-500 max-w-xs truncate" title={patient.address}>
                        {patient.address || '-'}
                      </td>

                      <td className="py-3 px-4">
                        {hasAlert ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-900 border border-amber-200">
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            {patient.allergies}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">لا يوجد</span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        {patient.patientType === 'new' ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700">
                            جديد
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                            متابع
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleSavePatientLocally(patient)}
                            disabled={savingPatientId === patient.id}
                            className="px-2.5 py-1 bg-white hover:bg-teal-50 text-teal-800 hover:text-teal-950 border border-teal-300 rounded text-[11px] font-bold transition-all flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap"
                            title="حفظ الملف وتنزيله محلياً (JSON + تقرير طبي HTML)"
                          >
                            <Download className={`w-3.5 h-3.5 text-teal-600 ${savingPatientId === patient.id ? 'animate-bounce' : ''}`} />
                            <span>{savingPatientId === patient.id ? 'جارٍ الحفظ...' : 'حفظ محلي'}</span>
                          </button>

                          <button
                            onClick={() => onOpenPatientDossier(patient.id)}
                            className="px-2.5 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                            title="فتح الملف الطبي الكامل"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>الملف</span>
                          </button>

                          <button
                            onClick={() => onOpenPatientDossier(patient.id, 'jaw-chart')}
                            className="px-2 py-1 bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-200/80 rounded text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                            title="فتح مخطط الفك والأسنان التفاعلي للمريض"
                          >
                            <Smile className="w-3.5 h-3.5 text-cyan-700" />
                            <span className="hidden sm:inline">مخطط الفك</span>
                          </button>

                          {patientFilesCount > 0 && (
                            <button
                              onClick={() => onOpenPatientDossier(patient.id, 'files')}
                              className="px-2 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded text-[11px] font-bold transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                              title="عرض صور وأشعة المريض"
                            >
                              <ImageIcon className="w-3 h-3" />
                              <span>الأشعة ({patientFilesCount})</span>
                            </button>
                          )}

                          <button
                            onClick={() => onBookAppointmentForPatient(patient.id)}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] transition-colors cursor-pointer"
                            title="حجز موعد جديد"
                          >
                            موعد
                          </button>

                          <button
                            onClick={() => handleOpenEdit(patient)}
                            title="تعديل البيانات"
                            className="p-1 text-slate-600 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setPatientToDelete(patient)}
                            title="حذف المريض"
                            className="p-1 text-rose-600 hover:bg-rose-50 rounded cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD / EDIT PATIENT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-xl w-full max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 font-heading tracking-tight flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-teal-600" />
                <span>{editingPatient ? `تعديل بيانات المريض (${editingPatient.fullName})` : 'إضافة مريض جديد'}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs leading-relaxed">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الاسم واللقب: <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="مثال: ياسمين بلقاسم"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم الهاتف (يبدأ بـ 05 / 06 / 07): <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0550123456"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    required
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    يجب أن يبدأ بـ 05 (أوريدو) أو 06 (موبيليس) أو 07 (جازي)
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    تاريخ الميلاد:
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                  {birthDate && calculateAge(birthDate) !== null && (
                    <span className="text-[11px] text-teal-700 font-semibold mt-0.5 block">
                      العمر المحسوب: {calculateAge(birthDate)} سنة
                    </span>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الجنس:
                  </label>
                  <div className="flex items-center gap-4 mt-2">
                    <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="gender"
                        value="male"
                        checked={gender === 'male'}
                        onChange={() => setGender('male')}
                        className="text-teal-600 focus:ring-teal-500"
                      />
                      <span>ذكر</span>
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="gender"
                        value="female"
                        checked={gender === 'female'}
                        onChange={() => setGender('female')}
                        className="text-teal-600 focus:ring-teal-500"
                      />
                      <span>أنثى</span>
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  العنوان / مكان الإقامة:
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="مثال: الجزائر العاصمة، حي باب الواد"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-amber-900">
                    الحساسية والمحاذير الطبية والأمراض المزمنة:
                  </label>
                  <span className="text-[10px] text-amber-800">انقر للإضافة السريعة</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'حساسية البنسلين',
                    'مرض السكري',
                    'ضغط الدم',
                    'أمراض القلب',
                    'حساسية التخدير الموضعي',
                    'حمل (Pregnant)',
                    'أدوية تخثر الدم',
                  ].map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => addAllergyTag(tag)}
                      className="px-2 py-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded text-[11px] transition-colors cursor-pointer"
                    >
                      + {tag}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                  placeholder="أدخل أي ملاحظات حساسية أو أمراض مزمنة..."
                  className="w-full px-3 py-2 bg-white border border-amber-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Disease Condition Dropdown */}
              <div
                ref={diseaseDropdownRef}
                className="p-3.5 bg-teal-50/50 rounded-xl border-2 border-teal-200/90 space-y-2.5 relative"
              >
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-1.5 text-xs font-extrabold font-heading text-teal-950">
                    <HeartPulse className="w-4 h-4 text-teal-600" />
                    <span>التشخيص السريري الرئيسي وحالة المرض:</span>
                  </label>
                  <span className="text-[10px] text-teal-700 font-bold">
                    تصنيف سريري معتمد
                  </span>
                </div>

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setIsDiseaseDropdownOpen(!isDiseaseDropdownOpen)}
                    className="w-full px-3.5 py-2.5 bg-white border-2 border-teal-300 hover:border-teal-500 rounded-xl text-xs text-right font-bold transition-all flex items-center justify-between shadow-2xs cursor-pointer group focus:outline-none focus:ring-2 focus:ring-teal-400"
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <HeartPulse className="w-4 h-4 text-teal-600 shrink-0 group-hover:scale-110 transition-transform" />
                      {diseaseCondition ? (
                        <span className={`px-2.5 py-1 rounded-md text-xs font-extrabold border ${getDiseaseBadgeStyle(diseaseCondition)}`}>
                          {diseaseCondition}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-medium">
                          اختر الحالة السريرية (تسوس، عصب، تقويم)...
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 text-teal-700 font-bold text-xs bg-teal-50 px-2 py-1 rounded-lg border border-teal-200 group-hover:bg-teal-100 transition-colors">
                      <span>{isDiseaseDropdownOpen ? 'إغلاق القائمة' : 'تغيير التصنيف'}</span>
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isDiseaseDropdownOpen ? 'rotate-180' : ''}`} />
                    </div>
                  </button>

                  {isDiseaseDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-1.5 z-40 bg-white rounded-xl border-2 border-teal-400 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                      <div className="p-2.5 bg-teal-50 border-b border-teal-100 flex items-center justify-between">
                        <span className="text-xs font-extrabold text-teal-950 flex items-center gap-1.5">
                          <HeartPulse className="w-3.5 h-3.5 text-teal-600" />
                          قائمة الحالات السريرية الشائعة
                        </span>
                        <span className="text-[10px] text-teal-700 font-bold">انقر للاختيار</span>
                      </div>
                      <div className="max-h-56 overflow-y-auto p-1.5 divide-y divide-slate-100">
                        {DENTAL_DISEASE_CONDITIONS.filter(c => c.id !== 'all').map((cond) => {
                          const isSelected = diseaseCondition === cond.label;
                          return (
                            <button
                              key={cond.id}
                              type="button"
                              onClick={() => {
                                setDiseaseCondition(cond.label);
                                setIsDiseaseDropdownOpen(false);
                              }}
                              className={`w-full text-right p-2.5 rounded-lg transition-all flex items-center justify-between text-xs font-bold cursor-pointer ${
                                isSelected
                                  ? 'bg-teal-100/90 text-teal-950 font-extrabold shadow-2xs'
                                  : 'hover:bg-teal-50/80 text-slate-800'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <span className={`w-2 h-2 rounded-full ${cond.badge ? cond.badge.split(' ')[0] : 'bg-teal-500'}`} />
                                <span className="font-heading">{cond.label}</span>
                              </div>
                              {isSelected ? (
                                <span className="text-[11px] text-teal-700 font-extrabold flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-teal-300">
                                  <Check className="w-3 h-3 text-teal-600" />
                                  محدد
                                </span>
                              ) : (
                                <span className="text-[11px] text-teal-600 font-medium">
                                  تحديد
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-col sm:flex-row pt-1">
                  <input
                    type="text"
                    value={diseaseCondition}
                    onChange={(e) => setDiseaseCondition(e.target.value)}
                    placeholder="أو اكتب تشخيصاً خاصاً (مثلاً: كسر في القاطع 11...)"
                    className="w-full sm:flex-1 px-3 py-2 bg-white border border-teal-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500 font-sans"
                  />
                  <select
                    value={diseaseStatus}
                    onChange={(e: any) => setDiseaseStatus(e.target.value)}
                    className="w-full sm:w-auto px-2.5 py-2 bg-white border border-teal-300 rounded-lg text-xs font-bold text-teal-900 focus:outline-none cursor-pointer"
                  >
                    <option value="active">نشط (Active)</option>
                    <option value="under_treatment">قيد العلاج</option>
                    <option value="urgent">طارئ ومستعجل</option>
                    <option value="completed">منتهي ومكتمل</option>
                    <option value="stable">مستقر</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5 text-[11px] text-teal-800 bg-teal-100/60 p-2 rounded-lg font-sans">
                  <HardDrive className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                  <span>تتيح لك الفلترة السريعة فرز المرضى حسب تشخيصهم وحالة أسنانهم في أي وقت.</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  نوع المريض:
                </label>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="patientType"
                      value="new"
                      checked={patientType === 'new'}
                      onChange={() => setPatientType('new')}
                      className="text-teal-600 focus:ring-teal-500"
                    />
                    <span>مريض جديد (أول زيارة)</span>
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="patientType"
                      value="returning"
                      checked={patientType === 'returning'}
                      onChange={() => setPatientType('returning')}
                      className="text-teal-600 focus:ring-teal-500"
                    />
                    <span>مريض متابع (زيارات سابقة)</span>
                  </label>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  يتحول المريض الجديد تلقائياً إلى &quot;متابع&quot; بمجرد إتمام أول موعد علاجي له.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات سريرية أولية:
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي معلومات إضافية عن المريض..."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                ></textarea>
              </div>

              {/* Photo & X-Ray Attachment Section */}
              <div className="p-4 bg-slate-50/90 rounded-xl border border-dashed border-teal-300/80 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-teal-600" />
                      <label className="text-xs font-bold font-heading text-slate-900">
                        إرفاق صور وأشعة سِنية فورية (اختياري):
                      </label>
                      {selectedPhotos.length > 0 && (
                        <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-800 font-mono">
                          {selectedPhotos.length} {selectedPhotos.length === 1 ? 'ملف مرفق' : 'ملفات مرفقة'}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5 font-sans">
                      يمكنك رفع الصور الشعاعية (Panoramique / RVG) وتقارير التحاليل مباشرة مع إنشاء الملف
                    </p>
                  </div>
                  <div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/*,.pdf"
                      className="hidden"
                      onChange={handleSelectPhotos}
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-2 px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold font-heading shadow-xs transition-all active:scale-95 cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>اختيار ملفات الأشعة</span>
                    </button>
                  </div>
                </div>

                {selectedPhotos.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                    {selectedPhotos.map((photo, idx) => (
                      <div
                        key={photo.id}
                        className="flex items-center gap-2.5 p-2 bg-white rounded-lg border border-slate-200 shadow-2xs group relative"
                      >
                        <div className="w-12 h-12 rounded-md bg-slate-100 overflow-hidden shrink-0 flex items-center justify-center border border-slate-200">
                          {photo.previewUrl ? (
                            <img
                              src={photo.previewUrl}
                              alt={photo.file.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <FileText className="w-6 h-6 text-slate-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-slate-800 truncate" title={photo.file.name}>
                            {photo.file.name}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            {(photo.file.size / 1024).toFixed(0)} KB
                          </p>
                          <select
                            value={photo.category}
                            onChange={(e) => handleUpdatePhotoCategory(idx, e.target.value)}
                            className="mt-1 w-full text-[10px] bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
                          >
                            {PHOTO_CATEGORIES.map(cat => (
                              <option key={cat.id} value={cat.id}>
                                {cat.label}
                              </option>
                            ))}
                          </select>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemovePhoto(idx)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
                          title="إزالة المرفق"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3.5 border border-dashed border-slate-300 rounded-lg text-center cursor-pointer hover:border-teal-400 hover:bg-teal-50/40 transition-colors"
                  >
                    <div className="flex flex-col items-center justify-center gap-1">
                      <div className="w-7 h-7 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center">
                        <Upload className="w-3.5 h-3.5" />
                      </div>
                      <p className="text-xs font-semibold text-slate-700">
                        انقر هنا لاختيار أو سحب صور الأشعة أو التقارير الطبية
                      </p>
                      <span className="text-[10px] text-slate-400">
                        يدعم صيغ JPG, PNG, WEBP ومستندات PDF (أشعة RVG أو بانوراما)
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting
                    ? (selectedPhotos.length > 0 ? 'جارٍ رفع الملفات وحفظ البيانات...' : 'جارٍ الحفظ...')
                    : editingPatient ? 'تحديث البيانات' : 'حفظ المريض'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Modal for Selecting / Updating Disease Condition */}
      {quickConditionPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
                  <HeartPulse className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold font-heading text-slate-900">
                    تعديل وتعيين تصنيف الحالة السريرية
                  </h3>
                  <p className="text-xs text-slate-500">
                    للمريض: <strong className="text-slate-800">{quickConditionPatient.fullName}</strong>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setQuickConditionPatient(null)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 rounded-md cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">
                اختر التشخيص السريري المناسب:
              </label>
              <div className="grid grid-cols-1 gap-1.5 max-h-64 overflow-y-auto p-1">
                {DENTAL_DISEASE_CONDITIONS.filter(c => c.id !== 'all').map(cond => (
                  <button
                    key={cond.id}
                    type="button"
                    onClick={() => handleSaveQuickCondition(quickConditionPatient, cond.label)}
                    className="w-full text-right p-2.5 rounded-xl border border-slate-200 hover:border-teal-400 hover:bg-teal-50/70 transition-all flex items-center justify-between text-xs font-bold text-slate-800 cursor-pointer group"
                  >
                    <span className="flex items-center gap-2">
                      <HeartPulse className="w-3.5 h-3.5 text-teal-600 group-hover:scale-110 transition-transform" />
                      <span>{cond.label}</span>
                    </span>
                    <span className="text-[10px] text-teal-700 font-semibold group-hover:underline">
                      اختيار وتحديث
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setQuickConditionPatient(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE PATIENT CONFIRMATION MODAL */}
      {patientToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-2xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-bold font-heading text-slate-900">
                  تأكيد حذف المريض نهائياً
                </h3>
                <p className="text-xs text-slate-500">
                  عملية الحذف لا يمكن التراجع عنها
                </p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 leading-relaxed space-y-2">
              <p>
                هل أنت متأكد من رغبتك في حذف ملف المريض:
              </p>
              <div className="font-bold text-sm text-slate-900 bg-white/80 p-2 rounded-lg border border-rose-200">
                {patientToDelete.fullName} ({patientToDelete.id})
              </div>
              <p className="text-[11px] text-rose-700">
                ⚠️ سيتم حذف جميع مواعيد المريض، وسجلات الأسنان، والملاحظات السريرية، وصور الأشعة المرفقة بهذا الملف.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                disabled={isDeletingPatient}
                onClick={() => setPatientToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                إلغاء التراجع
              </button>
              <button
                type="button"
                disabled={isDeletingPatient}
                onClick={async () => {
                  if (!patientToDelete) return;
                  setIsDeletingPatient(true);
                  try {
                    await onDeletePatient(patientToDelete.id);
                    setPatientToDelete(null);
                  } catch (err: any) {
                    onShowToast?.(err?.message || 'تعذر حذف المريض.');
                  } finally {
                    setIsDeletingPatient(false);
                  }
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingPatient ? 'جارٍ الحذف...' : 'نعم، حذف المريض نهائياً'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
