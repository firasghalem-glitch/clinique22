import React, { useState, useEffect } from 'react';
import { ClinicSettings, NetworkInfo, SmsLog } from '../types';
import { clinicApi } from '../services/api';
import {
  Download,
  Upload,
  Wifi,
  Save,
  HardDrive,
  Copy,
  Check,
  Server,
  Laptop,
  FileArchive,
  MessageSquare,
  Send,
  RefreshCw,
  Clock,
  Sliders,
  CheckCircle2,
  XCircle,
  Key,
  Globe,
  RotateCcw,
  Settings as SettingsIcon,
  Folder,
  FolderOpen,
  FolderCheck,
  AlertTriangle,
} from 'lucide-react';
import { localPatientStorageService } from '../utils/localPatientStorage';

interface SettingsBackupProps {
  settings: ClinicSettings;
  networkInfo: NetworkInfo;
  onUpdateSettings: (settings: Partial<ClinicSettings>) => Promise<ClinicSettings>;
  onExportBackup: () => Promise<void>;
  onRestoreBackup: (file: File) => Promise<{ success: boolean; message: string }>;
  patientsCount: number;
  filesCount: number;
}

const DEFAULT_TEMPLATE = 'مرحباً {patientName}، نذكركم بموعدكم في {clinicName} يوم {date} على الساعة {time} مع {doctorName}. الإجراء: {procedure}. للاستفسار: {phone}. دمتم بصحة وعافية.';

export const SettingsBackup: React.FC<SettingsBackupProps> = ({
  settings,
  networkInfo,
  onUpdateSettings,
  onExportBackup,
  onRestoreBackup,
  patientsCount,
  filesCount,
}) => {
  const [clinicName, setClinicName] = useState(settings.clinicName);
  const [doctorName, setDoctorName] = useState(settings.doctorName);
  const [phone, setPhone] = useState(settings.phone);
  const [address, setAddress] = useState(settings.address);
  const [storagePath, setStoragePath] = useState(settings.storagePath);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [settingsError, setSettingsError] = useState<string | null>(null);
  const folderInputRef = React.useRef<HTMLInputElement | null>(null);

  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const [smsEnabled, setSmsEnabled] = useState(settings.smsEnabled ?? true);
  const [smsProvider, setSmsProvider] = useState<'local_simulator' | 'custom' | 'twilio' | 'infobip'>(
    settings.smsProvider || 'local_simulator'
  );
  const [smsSenderName, setSmsSenderName] = useState(settings.smsSenderName || 'ElNourDental');
  const [smsApiKey, setSmsApiKey] = useState(settings.smsApiKey || '');
  const [smsApiUrl, setSmsApiUrl] = useState(settings.smsApiUrl || '');
  const [smsAccountSid, setSmsAccountSid] = useState(settings.smsAccountSid || '');
  const [smsAutoSend24h, setSmsAutoSend24h] = useState(settings.smsAutoSend24h ?? true);
  const [smsReminderTemplate, setSmsReminderTemplate] = useState(
    settings.smsReminderTemplate || DEFAULT_TEMPLATE
  );

  const [testPhoneNumber, setTestPhoneNumber] = useState('0550123456');
  const [isSendingTestSms, setIsSendingTestSms] = useState(false);
  const [testSmsFeedback, setTestSmsFeedback] = useState<{ success: boolean; msg: string } | null>(null);

  const [smsLogs, setSmsLogs] = useState<SmsLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [isTriggering24hCheck, setIsTriggering24hCheck] = useState(false);
  const [bulk24hFeedback, setBulk24hFeedback] = useState<{ count: number; msg: string } | null>(null);
  const [isEphemeral, setIsEphemeral] = useState<boolean>(false);

  useEffect(() => {
    loadSmsLogs();
    clinicApi.checkSystemStatus()
      .then(status => {
        if (status.persistent === false || status.storageType === 'ephemeral_cloud') {
          setIsEphemeral(true);
        }
      })
      .catch(() => {});
  }, []);

  const loadSmsLogs = async () => {
    setIsLoadingLogs(true);
    try {
      const logs = await clinicApi.getSmsLogs();
      setSmsLogs(logs);
    } catch (e) {
      console.warn('Could not load SMS logs:', e);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const handleNativeFolderPicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const firstFile = files[0];
      const relativePath = (firstFile as any).webkitRelativePath || '';
      const folder = relativePath.split('/')[0] || firstFile.name;
      if (folder) {
        setStoragePath(folder);
        localPatientStorageService.setFolderDirectly(folder);
      }
    }
    if (e.target) e.target.value = '';
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);
    setSettingsError(null);
    try {
      await onUpdateSettings({
        clinicName,
        doctorName,
        phone,
        address,
        storagePath,
        smsEnabled,
        smsProvider,
        smsSenderName,
        smsApiKey,
        smsApiUrl,
        smsAccountSid,
        smsAutoSend24h,
        smsReminderTemplate,
      });
      if (storagePath) {
        localPatientStorageService.setFolderDirectly(storagePath);
      }
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setSettingsError(err.message || 'فشل حفظ الإعدادات.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await onExportBackup();
    } catch (err: any) {
      alert(err.message || 'فشل تصدير النسخة الاحتياطية.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsRestoring(true);
    setRestoreMessage(null);
    try {
      const res = await onRestoreBackup(file);
      setRestoreMessage({ text: res.message, isError: !res.success });
      e.target.value = '';
    } catch (err: any) {
      setRestoreMessage({ text: err.message || 'فشل استعادة النسخة الاحتياطية', isError: true });
    } finally {
      setIsRestoring(false);
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const insertTemplateTag = (tag: string) => {
    setSmsReminderTemplate(prev => `${prev} ${tag}`);
  };

  const generatePreviewMessage = () => {
    const tomorrow = new Date(Date.now() + 86400000);
    const tomorrowStr = `${tomorrow.getDate().toString().padStart(2, '0')}/${(tomorrow.getMonth() + 1).toString().padStart(2, '0')}/${tomorrow.getFullYear()}`;
    return smsReminderTemplate
      .replace(/{patientName}/g, 'محمد العربي')
      .replace(/{clinicName}/g, clinicName || 'عيادة النور')
      .replace(/{date}/g, tomorrowStr)
      .replace(/{time}/g, '10:30')
      .replace(/{doctorName}/g, doctorName || 'د. محمد أمين')
      .replace(/{procedure}/g, 'علاج عصب (ضرس #46)')
      .replace(/{phone}/g, phone || '0550 11 22 33');
  };

  const handleSendTestSms = async () => {
    if (!testPhoneNumber) {
      alert('يرجى إدخال رقم هاتف تجريبي.');
      return;
    }
    setIsSendingTestSms(true);
    setTestSmsFeedback(null);
    try {
      const res = await clinicApi.sendTestSms(testPhoneNumber, smsReminderTemplate);
      setTestSmsFeedback({
        success: res.success,
        msg: res.message,
      });
      await loadSmsLogs();
    } catch (err: any) {
      setTestSmsFeedback({
        success: false,
        msg: err.message || 'فشل إرسال الرسالة التجريبية.',
      });
    } finally {
      setIsSendingTestSms(false);
    }
  };

  const handleTrigger24hReminders = async () => {
    setIsTriggering24hCheck(true);
    setBulk24hFeedback(null);
    try {
      const res = await clinicApi.checkAndSend24hSms();
      setBulk24hFeedback({
        count: res.sentCount,
        msg: res.sentCount > 0
          ? `تم إرسال تذكيرات SMS بنجاح لـ ${res.sentCount} مريض لديهم مواعيد غداً.`
          : 'تم الفحص: لا توجد مواعيد غير مذكر بها ليوم غد (أو تم إرسالها مسبقاً).',
      });
      await loadSmsLogs();
    } catch (err: any) {
      alert('خطأ أثناء فحص وإرسال المواعيد: ' + (err.message || 'فشل'));
    } finally {
      setIsTriggering24hCheck(false);
    }
  };

  const previewMessageText = generatePreviewMessage();
  const charLength = previewMessageText.length;
  const smsSegments = charLength <= 70 ? 1 : Math.ceil(charLength / 67);

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Ephemeral Cloud Warning Banner */}
      {isEphemeral && (
        <div className="p-4 bg-amber-50 border-2 border-amber-300 rounded-2xl text-amber-950 text-sm flex items-start gap-3 leading-relaxed shadow-sm">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-extrabold text-amber-900 block mb-0.5 text-base">
              تنبيه: أنت تعمل في بيئة سحابية تجريبية مؤقتة
            </span>
            البيانات تُمسح عند إعادة تشغيل الخادم. للاستخدام الفعلي في العيادة، يجب تشغيل التطبيق محلياً على حاسوب العيادة مع تحديد مجلد بيانات دائم عبر <code>DATA_DIR</code>.
          </div>
        </div>
      )}

      {/* Title */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-teal-50 border border-teal-100 text-teal-700 flex items-center justify-center shadow-2xs shrink-0">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-heading tracking-tight">
                إعدادات العيادة والنسخ الاحتياطي
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100/80 text-teal-800 font-heading">
                إدارة النظام
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 font-sans leading-relaxed">
              إعدادات الهوية السريرية، بوابة التذكير التلقائي (SMS)، والنسخ الاحتياطي الشامل (ZIP)
            </p>
          </div>
        </div>
      </div>

      {/* SMS Gateway */}
      <div className="bg-white rounded-2xl border-2 border-teal-500/30 p-5 sm:p-6 space-y-6 shadow-sm">
        <div className="flex items-center justify-between flex-wrap gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-sm">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  بوابة الرسائل القصيرة (SMS) والتذكير الآلي بالمواعيد
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800">
                  قبل 24 ساعة
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                إرسال رسائل تذكير للمرضى بمواعيد الغد تلقائياً
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTrigger24hReminders}
              disabled={isTriggering24hCheck}
              className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg text-xs font-bold transition-colors border border-teal-200 flex items-center gap-1.5 shadow-sm cursor-pointer"
              title="فحص وإرسال المواعيد لغد الآن فوراً"
            >
              {isTriggering24hCheck ? (
                <span className="w-3.5 h-3.5 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <Send className="w-3.5 h-3.5 text-teal-600" />
              )}
              <span>فحص وإرسال تذكيرات الغد الآن</span>
            </button>
          </div>
        </div>

        {bulk24hFeedback && (
          <div className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border animate-in fade-in ${
            bulk24hFeedback.count > 0
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-blue-50 border-blue-200 text-blue-800'
          }`}>
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{bulk24hFeedback.msg}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex items-start gap-3 ${
            smsEnabled ? 'bg-teal-50/60 border-teal-500 shadow-sm' : 'bg-slate-50 border-slate-200 opacity-70'
          }`}>
            <input
              type="checkbox"
              checked={smsEnabled}
              onChange={(e) => setSmsEnabled(e.target.checked)}
              className="mt-1 rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
            />
            <div>
              <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <span>تفعيل خدمة الرسائل القصيرة (SMS Gateway)</span>
                {smsEnabled && <span className="text-[10px] text-teal-700 font-bold bg-teal-100 px-1.5 py-0.2 rounded">مفعل</span>}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                يتيح للعيادة إرسال تذكيرات المواعيد لهواتف المرضى (أوريدو، موبيليس، جازي).
              </p>
            </div>
          </label>

          <label className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex items-start gap-3 ${
            smsAutoSend24h ? 'bg-teal-50/60 border-teal-500 shadow-sm' : 'bg-slate-50 border-slate-200 opacity-70'
          }`}>
            <input
              type="checkbox"
              checked={smsAutoSend24h}
              disabled={!smsEnabled}
              onChange={(e) => setSmsAutoSend24h(e.target.checked)}
              className="mt-1 rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
            />
            <div>
              <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-teal-600" />
                <span>الإرسال التلقائي لمواعيد الغد (24h Auto)</span>
                {smsAutoSend24h && <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.2 rounded">مفعل</span>}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                يقوم الخادم آلياً بفحص المواعيد المجدولة ليوم غد وإرسال رسائل التذكير.
              </p>
            </div>
          </label>
        </div>

        {/* Provider Settings */}
        <div className="bg-slate-50 p-4 sm:p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
            <Sliders className="w-4 h-4 text-teal-600" />
            <span>إعدادات بوابة ومزود خدمة الرسائل</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                مزود الخدمة (SMS Provider):
              </label>
              <select
                value={smsProvider}
                onChange={(e) => setSmsProvider(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:border-teal-500 cursor-pointer"
              >
                <option value="local_simulator">محاكي محلي (GSM أو بيئة تجريبية)</option>
                <option value="custom">بوابة خاصة REST API (Ooredoo / Mobilis / Djezzy / SMS-DZ)</option>
                <option value="twilio">بوابة Twilio SMS العالمية</option>
                <option value="infobip">بوابة Infobip SMS</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                اسم المرسل (Sender ID / اسم العيادة):
              </label>
              <input
                type="text"
                maxLength={11}
                value={smsSenderName}
                onChange={(e) => setSmsSenderName(e.target.value)}
                placeholder="ElNourDental"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-teal-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                أقصى طول: 11 حرفاً أبجدياً بالإنجليزية
              </span>
            </div>

            {smsProvider === 'custom' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-teal-600" />
                  <span>رابط البوابة (API Endpoint URL):</span>
                </label>
                <input
                  type="url"
                  value={smsApiUrl}
                  onChange={(e) => setSmsApiUrl(e.target.value)}
                  placeholder="https://api.sms-provider.dz/v1/send"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-800 focus:outline-none focus:border-teal-500"
                />
              </div>
            )}

            {(smsProvider === 'custom' || smsProvider === 'twilio' || smsProvider === 'infobip') && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Key className="w-3.5 h-3.5 text-amber-600" />
                  <span>مفتاح الـ API (API Key / Auth Token):</span>
                </label>
                <input
                  type="password"
                  value={smsApiKey}
                  onChange={(e) => setSmsApiKey(e.target.value)}
                  placeholder="أدخل المفتاح السري"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-800 focus:outline-none focus:border-teal-500"
                />
              </div>
            )}

            {smsProvider === 'twilio' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  معرّف الحساب (Account SID):
                </label>
                <input
                  type="text"
                  value={smsAccountSid}
                  onChange={(e) => setSmsAccountSid(e.target.value)}
                  placeholder="ACXXXXXXXXXXXXXXXXX"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-800 focus:outline-none focus:border-teal-500"
                />
              </div>
            )}
          </div>
        </div>

        {/* Template Editor */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <label className="block text-xs font-bold text-slate-900">
                نص وقالب رسالة التذكير بالميعاد:
              </label>
              <button
                type="button"
                onClick={() => setSmsReminderTemplate(DEFAULT_TEMPLATE)}
                className="text-[11px] text-teal-700 hover:text-teal-900 font-semibold flex items-center gap-1 cursor-pointer"
                title="إعادة تعيين القالب الافتراضي"
              >
                <RotateCcw className="w-3 h-3" />
                <span>القالب الافتراضي</span>
              </button>
            </div>

            <div className="relative">
              <textarea
                rows={5}
                value={smsReminderTemplate}
                onChange={(e) => setSmsReminderTemplate(e.target.value)}
                className="w-full p-3 bg-white border-2 border-slate-300 focus:border-teal-500 rounded-xl text-xs text-slate-800 leading-relaxed focus:outline-none focus:ring-1 focus:ring-teal-500"
                placeholder="اكتب قالب رسالة التذكير..."
              />
            </div>

            <div className="space-y-1.5">
              <div className="text-[11px] font-bold text-slate-600">
                انقر لإدراج المتغيرات الديناميكية في الرسالة:
              </div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { tag: '{patientName}', label: '+ اسم المريض' },
                  { tag: '{clinicName}', label: '+ اسم العيادة' },
                  { tag: '{date}', label: '+ التاريخ' },
                  { tag: '{time}', label: '+ التوقيت' },
                  { tag: '{doctorName}', label: '+ اسم الطبيب' },
                  { tag: '{procedure}', label: '+ الإجراء' },
                  { tag: '{phone}', label: '+ هاتف العيادة' },
                ].map(item => (
                  <button
                    key={item.tag}
                    type="button"
                    onClick={() => insertTemplateTag(item.tag)}
                    className="px-2 py-1 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 text-slate-700 rounded-md text-[11px] font-semibold border border-slate-200 transition-colors cursor-pointer"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
              <span className="font-mono">
                عدد الأحرف: <strong>{charLength}</strong> حرفاً
              </span>
              <span className="font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                حجم الرسالة: {smsSegments} {smsSegments === 1 ? 'رسالة SMS واحدة' : `${smsSegments} رسائل SMS`}
              </span>
            </div>
          </div>

          {/* Interactive Phone Simulation */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full max-w-[280px] bg-slate-900 rounded-[2.5rem] p-3 shadow-xl border-4 border-slate-800 relative">
              <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-2 flex items-center justify-center">
                <div className="w-2.5 h-2.5 bg-slate-900 rounded-full"></div>
              </div>
              <div className="bg-slate-100 rounded-[1.8rem] p-3 min-h-[310px] flex flex-col justify-between overflow-hidden text-right border border-slate-300">
                <div className="border-b border-slate-200 pb-2 text-center">
                  <div className="w-9 h-9 rounded-full bg-teal-600 text-white font-bold mx-auto flex items-center justify-center text-xs shadow-sm mb-1">
                    {smsSenderName.slice(0, 2).toUpperCase() || 'DZ'}
                  </div>
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {smsSenderName || 'عيادة الأسنان'}
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono">
                    رسالة SMS واردة
                  </div>
                </div>

                <div className="py-2 flex-1 flex flex-col justify-end">
                  <div className="text-[9px] text-center text-slate-400 mb-1 font-mono">
                    اليوم 09:30
                  </div>
                  <div className="bg-emerald-600 text-white p-3 rounded-2xl rounded-br-xs text-[11px] leading-relaxed shadow-sm">
                    {previewMessageText}
                    <div className="text-[8px] text-emerald-200 text-left mt-1 font-mono">
                      تم التسليم ✓✓
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 text-center text-[9px] text-slate-400">
                  محاكاة شكل الرسالة على هاتف المريض
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Test Gateway & Logs */}
        <div className="border-t border-slate-100 pt-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-teal-600" />
              <span>تجربة الإرسال السريع:</span>
            </h3>
            <span className="text-[11px] text-slate-500">
              أدخل رقم هاتف لاختبار عمل البوابة مباشرة
            </span>
          </div>

          <div className="flex items-center gap-2 max-w-md">
            <input
              type="tel"
              value={testPhoneNumber}
              onChange={(e) => setTestPhoneNumber(e.target.value)}
              placeholder="0550123456"
              className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-teal-500"
            />
            <button
              type="button"
              onClick={handleSendTestSms}
              disabled={isSendingTestSms}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 whitespace-nowrap disabled:opacity-50 cursor-pointer"
            >
              {isSendingTestSms ? (
                <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span>إرسال تجريبي</span>
            </button>
          </div>

          {testSmsFeedback && (
            <div className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 border animate-in fade-in ${
              testSmsFeedback.success
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}>
              {testSmsFeedback.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{testSmsFeedback.msg}</span>
            </div>
          )}

          <div className="pt-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>سجل رسائل SMS المرسلة مؤخراً ({smsLogs.length})</span>
              </span>
              <button
                type="button"
                onClick={loadSmsLogs}
                disabled={isLoadingLogs}
                className="text-[11px] text-teal-700 hover:text-teal-900 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingLogs ? 'animate-spin' : ''}`} />
                <span>تحديث السجل</span>
              </button>
            </div>

            {smsLogs.length === 0 ? (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center text-xs text-slate-400">
                لا توجد سجلات رسائل مرسلة بعد.
              </div>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-52 overflow-y-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 sticky top-0">
                    <tr>
                      <th className="py-2 px-3">المريض</th>
                      <th className="py-2 px-3">الهاتف</th>
                      <th className="py-2 px-3">نص الرسالة</th>
                      <th className="py-2 px-3">المزود</th>
                      <th className="py-2 px-3">الحالة</th>
                      <th className="py-2 px-3">الوقت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {smsLogs.slice(0, 10).map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-sans font-bold text-slate-800 truncate max-w-[120px]">
                          {log.patientName}
                        </td>
                        <td className="py-2 px-3 text-slate-700">
                          {log.phone}
                        </td>
                        <td className="py-2 px-3 font-sans text-slate-600 truncate max-w-[220px]" title={log.message}>
                          {log.message}
                        </td>
                        <td className="py-2 px-3 text-slate-500 uppercase text-[10px]">
                          {log.provider}
                        </td>
                        <td className="py-2 px-3">
                          {log.status === 'sent' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              تم الإرسال
                            </span>
                          ) : log.status === 'simulated' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                              محاكاة ناجحة
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800" title={log.error}>
                              فشل
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-slate-400 text-[10px]">
                          {log.sentAt.replace('T', ' ').slice(0, 16)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Backup and Restore */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-6 shadow-sm">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <FileArchive className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              النسخ الاحتياطي والاستعادة الكاملة (ZIP Backup)
            </h2>
            <p className="text-xs text-slate-500">
              تصدير قاعدة بيانات العيادة وكافة المرفقات والصور الشعاعية في ملف ZIP مضغوط
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-teal-50/60 rounded-xl border border-teal-200/80 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-teal-900 font-bold text-sm mb-1">
                <Download className="w-4 h-4 text-teal-700" />
                <span>تصدير نسخة احتياطية</span>
              </div>
              <p className="text-xs text-teal-800 leading-relaxed">
                تنزيل ملف ZIP شامل يحتوي على قاعدة البيانات كاملة ومجلد صور وأشعة المرضى.
              </p>
              <div className="mt-3 bg-white/80 p-3 rounded-lg border border-teal-200 text-xs text-slate-600 space-y-1">
                <div>إجمالي المرضى: <strong>{patientsCount}</strong></div>
                <div>إجمالي ملفات الأشعة: <strong>{filesCount}</strong></div>
                <div>التوصية: <strong>احفظ ملف ZIP يومياً</strong> على فلاش ميموري USB خارجي.</div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleExport}
              disabled={isExporting}
              className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold shadow-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'جارٍ إنشاء النسخة...' : 'تصدير النسخة الاحتياطية (ZIP)'}</span>
            </button>
          </div>

          <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm mb-1">
                <Upload className="w-4 h-4 text-slate-700" />
                <span>استعادة نسخة احتياطية</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                رفع ملف ZIP تم تصديره مسبقاً لاسترجاع المرضى والمواعيد والملفات.
              </p>
              {restoreMessage && (
                <div className={`mt-3 p-3 rounded-lg text-xs border ${
                  restoreMessage.isError ? 'bg-rose-50 border-rose-200 text-rose-700' : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                }`}>
                  {restoreMessage.text}
                </div>
              )}
            </div>

            <label className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4" />
              <span>{isRestoring ? 'جارٍ الاستعادة...' : 'اختيار ملف النسخة (.zip)...'}</span>
              <input
                type="file"
                accept=".zip"
                onChange={handleRestoreFile}
                disabled={isRestoring}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* LAN Network */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-5 shadow-sm">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
            <Wifi className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              ربط الأجهزة على شبكة العيادة المحلية (LAN)
            </h2>
            <p className="text-xs text-slate-500">
              عناوين الوصول من الأجهزة الأخرى المتصلة بنفس شبكة الراوتر
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs mb-2">
              <Server className="w-4 h-4 text-teal-600" />
              <span>الجهاز الرئيسي (الخادم)</span>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              الوصول من نفس الكمبيوتر المشغّل للنظام:
            </p>
            <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-slate-200 font-mono text-xs text-teal-700 font-bold">
              <span>{networkInfo.localUrl}</span>
              <button
                type="button"
                onClick={() => handleCopyUrl(networkInfo.localUrl)}
                className="p-1 hover:bg-slate-100 rounded text-slate-500 cursor-pointer"
                title="نسخ الرابط"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 flex flex-col justify-between md:col-span-2">
            <div>
              <div className="flex items-center gap-2 text-blue-900 font-bold text-xs mb-2">
                <Laptop className="w-4 h-4 text-blue-700" />
                <span>الأجهزة الأخرى في العيادة (Wi-Fi / كابل شبكة)</span>
              </div>
              <p className="text-xs text-blue-800 mb-3 leading-relaxed">
                استخدم هذا العنوان لفتح لوحة التحكم من جهاز الاستقبال أو حاسوب المساعد(ة) المتصل بنفس شبكة Wi-Fi:
              </p>
            </div>
            <div className="space-y-1.5">
              {networkInfo.networkUrls.length > 0 ? (
                networkInfo.networkUrls.map((url, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-white px-3 py-1.5 rounded-lg border border-blue-200 font-mono text-xs text-blue-900 font-bold">
                    <span>{url}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyUrl(url)}
                      className="p-1 hover:bg-slate-100 rounded text-slate-500 cursor-pointer"
                      title="نسخ الرابط"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-500 italic bg-white p-2 rounded border border-slate-200">
                  جارٍ تحديد عنوان الـ IP للشبكة...
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Storage and Identity */}
      <form onSubmit={handleSaveSettings} className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-6 shadow-sm">
        {settingsError && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-bold">
            {settingsError}
          </div>
        )}

        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <HardDrive className="w-4 h-4 text-teal-600" />
              <span>مجلد ومسار حفظ ملفات المرضى والأشعة على القرص الصلب</span>
            </div>
            <button
              type="button"
              onClick={() => folderInputRef.current?.click()}
              className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <FolderOpen className="w-3.5 h-3.5 text-teal-600" />
              <span>استعراض المجلدات 📂</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              dir="ltr"
              value={storagePath}
              onChange={(e) => setStoragePath(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              placeholder="clinic_data/patient_files أو D:\ClinicData"
              required
            />
            <input
              type="file"
              ref={folderInputRef}
              // @ts-ignore
              webkitdirectory=""
              directory=""
              multiple={false}
              className="hidden"
              onChange={handleNativeFolderPicked}
            />
          </div>

          {/* Quick folder presets */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            <span className="text-[11px] font-bold text-slate-500">مجلدات مقترحة سريعة:</span>
            {[
              { label: 'القرص C (بيانات العيادة)', path: 'C:\\ClinicData' },
              { label: 'القرص D (ملفات المرضى)', path: 'D:\\ClinicData\\Patients' },
              { label: 'المستندات', path: 'Documents\\DentalClinic' },
              { label: 'المجلد الافتراضي', path: 'clinic_data/patient_files' },
            ].map(item => (
              <button
                key={item.path}
                type="button"
                onClick={() => setStoragePath(item.path)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition-colors border cursor-pointer ${
                  storagePath === item.path
                    ? 'bg-teal-100 text-teal-900 border-teal-300 font-bold'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <span className="text-[11px] text-slate-500 mt-1.5 block leading-relaxed">
            المسار الافتراضي: <code className="font-mono bg-slate-100 px-1 py-0.2 rounded">clinic_data/patient_files</code>. يتم إنشاء مجلد مخصص لكل مريض تلقائياً باسم: <strong>(الاسم_رقم_الملف)</strong> داخل المجلد المعتمد.
          </span>
        </div>

        <div className="border-t border-slate-100 pt-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-900">
            بيانات وهوية العيادة (تظهر في الفواتير والتقارير الطبية)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                اسم العيادة:
              </label>
              <input
                type="text"
                value={clinicName}
                onChange={(e) => setClinicName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-teal-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                اسم الطبيب المسؤول:
              </label>
              <input
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-teal-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                أرقام هاتف العيادة (تظهر في تذكيرات SMS):
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                عنوان العيادة:
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-100 flex-wrap gap-2">
          {saveSuccess ? (
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
              <Check className="w-4 h-4" />
              تم حفظ وتحديث الإعدادات وبوابة SMS بنجاح
            </span>
          ) : (
            <span className="text-xs text-slate-400">
              يتم حفظ التغييرات فوراً في قاعدة البيانات وتطبيقها على كامل النظام
            </span>
          )}
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors shadow-sm flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'جارٍ الحفظ...' : 'حفظ الإعدادات'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
