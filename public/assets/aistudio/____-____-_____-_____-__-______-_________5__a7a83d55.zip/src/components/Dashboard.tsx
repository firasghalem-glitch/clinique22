import React, { useState, useEffect, useMemo } from 'react';
import {
  Appointment,
  Patient,
  DashboardStats,
  NetworkInfo,
  DentalCondition,
  ClinicalNote,
  PatientFile,
  ClinicSettings,
} from '../types';
import {
  Calendar,
  Users,
  UserPlus,
  Clock,
  CheckCircle2,
  Phone,
  Download,
  Wifi,
  TrendingUp,
  BarChart3,
  LineChart,
  Activity,
  ChevronDown,
  ChevronUp,
  Sparkles,
  HardDrive,
  Folder,
  FolderCheck,
  FolderOpen,
  Edit3,
  Save,
  Check,
  RefreshCw,
  FileArchive,
  ArrowDownToLine,
} from 'lucide-react';
import { clinicApi } from '../services/api';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';
import { localPatientStorageService, LocalFolderInfo } from '../utils/localPatientStorage';

interface DashboardProps {
  stats: DashboardStats;
  patients: Patient[];
  appointments?: Appointment[];
  conditions?: DentalCondition[];
  notes?: ClinicalNote[];
  files?: PatientFile[];
  settings?: ClinicSettings;
  onOpenPatientDossier: (patientId: string) => void;
  onAddNewPatient: () => void;
  onBookAppointment: () => void;
  onQuickBackup: () => void;
  onCompleteAppointment: (appointmentId: string) => void;
  networkInfo: NetworkInfo;
  onAddAppointment?: (appointment: Omit<Appointment, 'id' | 'createdAt'>) => Promise<void>;
  onShowToast?: (message: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  stats,
  patients,
  appointments,
  conditions,
  notes,
  files,
  settings,
  onOpenPatientDossier,
  onAddNewPatient,
  onBookAppointment,
  onQuickBackup,
  onCompleteAppointment,
  networkInfo,
  onShowToast,
}) => {
  const [chartType, setChartType] = useState<'bar' | 'area'>('bar');
  const [folderInfo, setFolderInfo] = useState<LocalFolderInfo>(() => localPatientStorageService.getFolderInfo());
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [folderInputVal, setFolderInputVal] = useState(
    folderInfo.folderName || folderInfo.customPath || settings?.storagePath || 'C:\\ClinicData'
  );
  const [modalSelectedDrive, setModalSelectedDrive] = useState<string>('D:\\');
  const [modalCustomSubfolder, setModalCustomSubfolder] = useState<string>('ClinicData');
  const hiddenFolderPickerRef = React.useRef<HTMLInputElement | null>(null);
  const hiddenFilePickerRef = React.useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (settings?.storagePath && !folderInfo.folderName) {
      localPatientStorageService.setFolderDirectly(settings.storagePath);
      setFolderInfo(localPatientStorageService.getFolderInfo());
      setFolderInputVal(settings.storagePath);
    }
  }, [settings?.storagePath]);

  const [isExportingAll, setIsExportingAll] = useState(false);
  const [exportFeedback, setExportFeedback] = useState<string | null>(null);
  const [patientPeriod, setPatientPeriod] = useState<'today' | 'week' | 'month' | 'year'>('month');
  const [expandedCard, setExpandedCard] = useState<'new' | 'returning' | null>(null);

  const getPatient = (id: string) => patients.find(p => p.id === id);

  const formatDateDZ = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  const currentYear = stats.currentYear || new Date().getFullYear();
  const arabicMonths = [
    'جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان',
    'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  const todayStr = new Date().toISOString().split('T')[0];

  const getWeekRange = () => {
    const d = new Date();
    const day = d.getDay();
    const daysSinceSat = (day + 1) % 7;
    const sat = new Date(d);
    sat.setDate(d.getDate() - daysSinceSat);
    sat.setHours(0, 0, 0, 0);
    const startStr = sat.toISOString().split('T')[0];
    const fri = new Date(sat);
    fri.setDate(sat.getDate() + 6);
    fri.setHours(23, 59, 59, 999);
    const endStr = fri.toISOString().split('T')[0];
    return { startStr, endStr };
  };

  const weekRange = getWeekRange();
  const currentMonthPrefix = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
  const currentYearPrefix = `${new Date().getFullYear()}`;

  const periodData = useMemo(() => {
    const allApts = (appointments && appointments.length > 0)
      ? appointments
      : (stats.todayAppointmentsList || []);

    const isInPeriod = (dateStr?: string) => {
      if (!dateStr) return false;
      const d = dateStr.slice(0, 10);
      if (patientPeriod === 'today') return d === todayStr;
      if (patientPeriod === 'week') return d >= weekRange.startStr && d <= weekRange.endStr;
      if (patientPeriod === 'month') return d.startsWith(currentMonthPrefix);
      if (patientPeriod === 'year') return d.startsWith(currentYearPrefix);
      return false;
    };

    let newPatientsList = patients.filter(p => isInPeriod(p.createdAt));
    let newCount = newPatientsList.length;
    if (patientPeriod === 'month' && newCount === 0 && stats.newPatientsThisMonth > 0) {
      newCount = stats.newPatientsThisMonth;
      newPatientsList = patients.filter(p => p.patientType === 'new');
    }

    const aptsInPeriod = allApts.filter(a => isInPeriod(a.appointmentDate));
    const ptIdsInApts = Array.from(new Set(aptsInPeriod.map(a => a.patientId)));

    let returningPatientsList = ptIdsInApts
      .map(id => patients.find(p => p.id === id))
      .filter((p): p is Patient => !!p && (p.patientType === 'returning' || !isInPeriod(p.createdAt)));
    let returningCount = returningPatientsList.length;

    if (patientPeriod === 'year') {
      const allReturning = patients.filter(p => p.patientType === 'returning');
      returningCount = Math.max(returningCount, allReturning.length);
      returningPatientsList = allReturning;
    } else if (patientPeriod === 'month') {
      const allReturning = patients.filter(p => p.patientType === 'returning');
      if (returningCount === 0 && stats.returningPatientsCount > 0) {
        returningCount = stats.returningPatientsCount;
        returningPatientsList = allReturning;
      } else {
        returningCount = Math.max(returningCount, allReturning.length > 0 ? 1 : 0);
      }
    } else if (patientPeriod === 'today') {
      const todayReturningApts = stats.todayAppointmentsList?.filter(a => {
        const p = patients.find(pt => pt.id === a.patientId);
        return p && p.patientType === 'returning';
      }) || [];
      if (returningCount === 0 && todayReturningApts.length > 0) {
        returningCount = todayReturningApts.length;
        returningPatientsList = todayReturningApts.map(a => patients.find(p => p.id === a.patientId)!).filter(Boolean);
      }
    }

    const totalPatientIds = new Set([
      ...newPatientsList.map(p => p.id),
      ...returningPatientsList.map(p => p.id)
    ]);
    let totalInPeriod = totalPatientIds.size;
    if (totalInPeriod === 0) {
      totalInPeriod = newCount + returningCount;
    }
    if (patientPeriod === 'year') {
      totalInPeriod = Math.max(totalInPeriod, patients.length);
    }

    const periodLabels = {
      today: { title: 'اليوم', desc: `إحصائيات اليوم (${formatDateDZ(todayStr)})`, tag: 'اليوم' },
      week: { title: 'هذا الأسبوع', desc: `من السبت ${formatDateDZ(weekRange.startStr)} إلى الجمعة ${formatDateDZ(weekRange.endStr)}`, tag: 'هذا الأسبوع' },
      month: { title: `هذا الشهر (${arabicMonths[new Date().getMonth()]})`, desc: `شهر ${arabicMonths[new Date().getMonth()]} ${new Date().getFullYear()}`, tag: 'هذا الشهر' },
      year: { title: `هذه السنة ${currentYear}`, desc: `كامل سنة ${currentYear}`, tag: 'هذه السنة' },
    };

    return {
      newCount,
      newPatientsList,
      returningCount,
      returningPatientsList,
      totalInPeriod,
      totalClinicOverall: patients.length,
      appointmentsCount: aptsInPeriod.length,
      label: periodLabels[patientPeriod],
    };
  }, [patients, appointments, stats, patientPeriod, todayStr, weekRange.startStr, weekRange.endStr, currentMonthPrefix, currentYearPrefix, currentYear]);

  const yearlyChartData = (stats.yearlyDistribution && stats.yearlyDistribution.length === 12)
    ? stats.yearlyDistribution
    : arabicMonths.map((mName, idx) => {
        const monthNum = String(idx + 1).padStart(2, '0');
        const prefix = `${currentYear}-${monthNum}`;
        const count = patients.filter(p => p.createdAt && p.createdAt.startsWith(prefix)).length;
        return {
          month: monthNum,
          monthLabel: mName,
          shortLabel: mName,
          newPatients: count,
          year: currentYear,
        };
      });

  const totalYearlyNewPatients = yearlyChartData.reduce((acc, curr) => acc + curr.newPatients, 0);
  const maxMonthItem = yearlyChartData.reduce((max, curr) => curr.newPatients > max.newPatients ? curr : max, yearlyChartData[0]);
  const avgMonthlyNewPatients = (totalYearlyNewPatients / 12).toFixed(1);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white px-3.5 py-2.5 rounded-xl shadow-xl text-xs border border-slate-700 min-w-[150px] text-right">
          <div className="font-bold text-teal-300 mb-1">
            شهر {data.monthLabel} {data.year || currentYear}
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-200">
            <span>المرضى الجدد:</span>
            <span className="font-bold font-mono text-emerald-400 tabular-nums">
              {payload[0].value} {payload[0].value === 1 ? 'مريض' : payload[0].value === 2 ? 'مريضان' : 'مرضى'}
            </span>
          </div>
          {totalYearlyNewPatients > 0 && (
            <div className="text-[10px] text-slate-400 mt-1 border-t border-slate-800 pt-1 flex items-center justify-between">
              <span>النسبة السنوية:</span>
              <span className="font-mono text-teal-400">
                {((payload[0].value / totalYearlyNewPatients) * 100).toFixed(0)}%
              </span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const handleApplyFolder = async (pathStr: string) => {
    const clean = pathStr.trim();
    if (!clean) return;
    localPatientStorageService.setFolderDirectly(clean);
    setFolderInfo(localPatientStorageService.getFolderInfo());
    setFolderInputVal(clean);
    setIsFolderModalOpen(false);
    if (onShowToast) {
      onShowToast(`تم اعتماد المجلد بنجاح: "${clean}"`);
    }
    setExportFeedback(`تم اعتماد وتعيين المجلد المحلي بنجاح: "${clean}".`);
    try {
      await clinicApi.updateSettings({ storagePath: clean });
    } catch (e) {
      // client update still effective
    }
  };

  const handleSelectFolder = async () => {
    // 1. Try modern browser directory picker (File System Access API)
    try {
      const res = await localPatientStorageService.selectLocalFolder();
      if (res.success) {
        setFolderInfo(localPatientStorageService.getFolderInfo());
        setFolderInputVal(res.folderName);
        if (onShowToast) onShowToast(res.message);
        setExportFeedback(`تم ربط المجلد المحلي بنجاح: "${res.folderName}".`);
        try {
          await clinicApi.updateSettings({ storagePath: res.folderName });
        } catch (e) {}
        return;
      }
    } catch (e) {
      // ignore and fallback
    }

    // 2. Open interactive selector modal or native dialog
    if (hiddenFolderPickerRef.current) {
      hiddenFolderPickerRef.current.click();
    } else {
      setIsFolderModalOpen(true);
    }
  };

  const handleNativeFolderSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const firstFile = files[0];
      const relativePath = (firstFile as any).webkitRelativePath || '';
      const folder = relativePath.split('/')[0] || firstFile.name;
      if (folder) {
        handleApplyFolder(folder);
      }
    } else {
      // If folder was empty, open the modal so user can confirm path
      setIsFolderModalOpen(true);
    }
    if (e.target) e.target.value = '';
  };

  const handleNativeFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const relPath = (file as any).webkitRelativePath || '';
      let folder = relPath ? relPath.split('/')[0] : '';
      if (!folder && file.name) {
        folder = `D:\\ClinicData`;
      }
      if (folder) {
        handleApplyFolder(folder);
      }
    }
    if (e.target) e.target.value = '';
  };

  const handleToggleAutoSave = () => {
    const nextState = !folderInfo.autoSaveEnabled;
    localPatientStorageService.setAutoSave(nextState);
    setFolderInfo(localPatientStorageService.getFolderInfo());
    if (onShowToast) {
      onShowToast(nextState ? 'تم تفعيل الحفظ المحلي التلقائي.' : 'تم إيقاف الحفظ المحلي التلقائي.');
    }
  };

  const handleSaveAllPatientsInOneFile = async () => {
    setIsExportingAll(true);
    setExportFeedback(null);
    try {
      const res = await localPatientStorageService.saveAllPatientsInOneFile(
        patients,
        appointments || [],
        conditions || [],
        notes || [],
        files || [],
        settings
      );
      const msg = `تم بنجاح تصدير جميع ملفات المرضى (${res.patientCount} مريض) في ملف أرشيف موحد (${res.fileName})`;
      setExportFeedback(msg);
      if (onShowToast) onShowToast(msg);
    } catch (e: any) {
      setExportFeedback(`خطأ أثناء التصدير: ${e.message}`);
    } finally {
      setIsExportingAll(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner for Empty / Brand New Clinic */}
      {patients.length === 0 && (
        <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-emerald-900 rounded-2xl p-6 sm:p-7 text-white shadow-lg relative overflow-hidden border border-teal-700/50">
          <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 relative z-10">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-200 text-xs font-bold border border-teal-400/30">
                <Sparkles className="w-3.5 h-3.5 text-teal-300" />
                <span>مرحباً بك في منظومة عيادتك الجديدة!</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold font-heading text-white">
                مساحة بيانات عيادتك جاهزة ومستقلة بالكامل
              </h2>
              <p className="text-xs sm:text-sm text-teal-100/90 max-w-2xl leading-relaxed">
                عيادتك حالياً فارغة وجاهزة لاستقبال أول مريض. يمكنك البدء بإضافة ملف أول مريض، أو إضافة موظفيك من قسم &quot;إدارة الفريق&quot; لمساعدتك في حجز المواعيد وإدارة الملفات.
              </p>
            </div>
            <button
              type="button"
              onClick={onAddNewPatient}
              className="px-5 py-3 bg-white text-teal-900 hover:bg-teal-50 rounded-xl font-bold font-heading text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
            >
              <UserPlus className="w-4 h-4 text-teal-700" />
              <span>إضافة أول مريض للعيادة</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-heading tracking-tight">
            لوحة تحكم وإحصائيات العيادة
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5 font-sans leading-relaxed">
            متابعة فورية للمواعيد، المرضى الجدد والمتابعين، والملفات المحفوظة
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onAddNewPatient}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>إضافة مريض</span>
          </button>
          <button
            onClick={onBookAppointment}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>حجز موعد</span>
          </button>
          <button
            onClick={onQuickBackup}
            className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            title="تصدير نسخة احتياطية ZIP سريعة"
          >
            <Download className="w-4 h-4 text-teal-600" />
            <span>نسخ احتياطي</span>
          </button>
        </div>
      </div>

      {/* Patient Period Statistics Control & Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-teal-600" />
              <h2 className="text-base sm:text-lg font-bold font-heading text-slate-900 tracking-tight">
                إحصائيات توافد المرضى على العيادة
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              حساب دقيق لعدد المرضى الجدد والمتابعين ({periodData.label.desc})
            </p>
          </div>

          <div className="flex items-center bg-slate-100/90 p-1.5 rounded-2xl border border-teal-200/80 shadow-xs gap-1">
            {(['today', 'week', 'month', 'year'] as const).map(pKey => {
              const labelMap = {
                today: 'اليوم',
                week: 'هذا الأسبوع',
                month: 'هذا الشهر',
                year: 'هذه السنة',
              };
              const isSelected = patientPeriod === pKey;
              return (
                <button
                  key={pKey}
                  type="button"
                  onClick={() => {
                    setPatientPeriod(pKey);
                    setExpandedCard(null);
                  }}
                  className={`px-4 py-1.5 text-xs font-extrabold rounded-xl transition-all duration-200 cursor-pointer ${
                    isSelected
                      ? 'bg-linear-to-r from-teal-600 to-emerald-600 text-white shadow-md shadow-teal-600/25 scale-[1.02]'
                      : 'text-slate-600 hover:text-teal-950 hover:bg-white/80'
                  }`}
                >
                  {labelMap[pKey]}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. New Patients */}
          <div className="relative overflow-hidden bg-linear-to-br from-emerald-500/15 via-teal-500/5 to-white p-5 rounded-2xl border-2 border-emerald-300/90 shadow-xs hover:shadow-md hover:border-emerald-400 transition-all flex flex-col justify-between group">
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-linear-to-r from-emerald-500 via-teal-400 to-emerald-600"></div>
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-extrabold font-heading text-emerald-950">مرضى جدد</span>
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-600 text-white font-bold font-mono shadow-2xs">
                    {periodData.label.tag}
                  </span>
                </div>
                <div className="w-11 h-11 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/25 group-hover:scale-105 transition-transform">
                  <UserPlus className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-emerald-950 tabular-nums font-heading tracking-tight">
                  {periodData.newCount}
                </span>
                <span className="text-xs text-emerald-800 font-bold font-heading px-2 py-0.5 bg-emerald-100/90 rounded-md border border-emerald-200">
                  {periodData.newCount === 1 ? 'مريض جديد' : 'مرضى جدد'}
                </span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-emerald-200/70 flex items-center justify-between text-xs text-emerald-900 font-sans">
              <span className="font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                أول زيارة لهم
              </span>
              {periodData.newPatientsList.length > 0 && (
                <button
                  type="button"
                  onClick={() => setExpandedCard(expandedCard === 'new' ? null : 'new')}
                  className="text-[11px] font-extrabold text-emerald-800 hover:text-emerald-950 bg-emerald-100/80 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 border border-emerald-300 shadow-2xs cursor-pointer"
                >
                  <span>عرض القائمة ({periodData.newPatientsList.length})</span>
                  {expandedCard === 'new' ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
              )}
            </div>
          </div>

          {/* 2. Returning Patients */}
          <div className="relative overflow-hidden bg-linear-to-br from-sky-500/15 via-blue-500/5 to-white p-5 rounded-2xl border-2 border-sky-300/90 shadow-xs hover:shadow-md hover:border-sky-400 transition-all flex flex-col justify-between group">
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-linear-to-r from-sky-500 via-blue-400 to-cyan-500"></div>
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-extrabold font-heading text-sky-950">مرضى متابعون</span>
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-sky-600 text-white font-bold font-mono shadow-2xs">
                    {periodData.label.tag}
                  </span>
                </div>
                <div className="w-11 h-11 rounded-2xl bg-sky-500 text-white flex items-center justify-center shadow-md shadow-sky-500/25 group-hover:scale-105 transition-transform">
                  <Users className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-sky-950 tabular-nums font-heading tracking-tight">
                  {periodData.returningCount}
                </span>
                <span className="text-xs text-sky-800 font-bold font-heading px-2 py-0.5 bg-sky-100/90 rounded-md border border-sky-200">
                  مريض متابع
                </span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-sky-200/70 flex items-center justify-between text-xs text-sky-900 font-sans">
              <span className="font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                جلسات متابعة مستمرة
              </span>
              {periodData.returningPatientsList.length > 0 && (
                <button
                  type="button"
                  onClick={() => setExpandedCard(expandedCard === 'returning' ? null : 'returning')}
                  className="text-[11px] font-extrabold text-sky-800 hover:text-sky-950 bg-sky-100/80 hover:bg-sky-200 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 border border-sky-300 shadow-2xs cursor-pointer"
                >
                  <span>عرض القائمة ({periodData.returningPatientsList.length})</span>
                  {expandedCard === 'returning' ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
              )}
            </div>
          </div>

          {/* 3. Total in Period */}
          <div className="relative overflow-hidden bg-linear-to-br from-teal-500/18 via-cyan-500/6 to-white p-5 rounded-2xl border-2 border-teal-300/90 shadow-xs hover:shadow-md hover:border-teal-400 transition-all flex flex-col justify-between group">
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-linear-to-r from-teal-600 via-cyan-400 to-teal-500"></div>
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-extrabold font-heading text-teal-950">إجمالي المراجعين</span>
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-teal-700 text-white font-bold font-mono shadow-2xs">
                    {periodData.label.tag}
                  </span>
                </div>
                <div className="w-11 h-11 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-md shadow-teal-600/25 group-hover:scale-105 transition-transform">
                  <Activity className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-teal-950 tabular-nums font-heading tracking-tight">
                  {periodData.totalInPeriod}
                </span>
                <span className="text-xs text-teal-800 font-bold font-heading px-2 py-0.5 bg-teal-100/90 rounded-md border border-teal-200">
                  مريض خلال {periodData.label.tag}
                </span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-teal-200/70 flex items-center justify-between text-xs text-teal-900 font-sans">
              <span className="font-semibold">المجموع الكلي:</span>
              <span className="text-[11px] font-sans px-2 py-0.5 rounded-md bg-teal-100/90 border border-teal-200 text-teal-900 font-bold">
                في السجل: <strong className="font-mono text-teal-950 font-extrabold">{periodData.totalClinicOverall}</strong>
              </span>
            </div>
          </div>

          {/* 4. Today Appointments */}
          <div className="relative overflow-hidden bg-linear-to-br from-indigo-500/15 via-violet-500/6 to-white p-5 rounded-2xl border-2 border-indigo-300/90 shadow-xs hover:shadow-md hover:border-indigo-400 transition-all flex flex-col justify-between group">
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-linear-to-r from-indigo-600 via-purple-400 to-indigo-500"></div>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold font-heading text-indigo-950">مواعيد اليوم</span>
                <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/25 group-hover:scale-105 transition-transform">
                  <Calendar className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-indigo-950 tabular-nums font-heading tracking-tight">
                  {stats.todayAppointmentsCount}
                </span>
                <span className="text-xs text-indigo-800 font-bold font-heading px-2 py-0.5 bg-indigo-100/90 rounded-md border border-indigo-200">
                  ({stats.todayAppointmentsCompleted} مكتمل)
                </span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-indigo-200/70 flex items-center justify-between text-xs text-indigo-950 font-sans">
              <span className="font-semibold">{stats.todayAppointmentsScheduled} قادم</span>
              <button
                type="button"
                onClick={onBookAppointment}
                className="text-[11px] font-extrabold text-white bg-linear-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-3 py-1.5 rounded-lg transition-all shadow-xs hover:shadow-md cursor-pointer"
              >
                + حجز
              </button>
            </div>
          </div>
        </div>

        {/* Expandable Details Tray */}
        {expandedCard && (
          <div className={`mt-4 p-5 rounded-2xl border animate-in fade-in duration-200 shadow-xs ${
            expandedCard === 'new'
              ? 'bg-linear-to-br from-emerald-50/80 to-teal-50/40 border-emerald-300'
              : 'bg-linear-to-br from-sky-50/80 to-blue-50/40 border-sky-300'
          }`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                  expandedCard === 'new' ? 'bg-emerald-600 text-white' : 'bg-sky-600 text-white'
                }`}>
                  <Users className="w-4 h-4" />
                </div>
                <h3 className={`text-sm font-extrabold font-heading ${
                  expandedCard === 'new' ? 'text-emerald-950' : 'text-sky-950'
                }`}>
                  {expandedCard === 'new' && `قائمة المرضى الجدد (${periodData.label.desc})`}
                  {expandedCard === 'returning' && `قائمة المرضى المتابعين (${periodData.label.desc})`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setExpandedCard(null)}
                className="text-xs px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 font-bold transition-colors cursor-pointer"
              >
                إغلاق القائمة
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {(expandedCard === 'new' ? periodData.newPatientsList : periodData.returningPatientsList).map(pt => (
                <div
                  key={pt.id}
                  className="bg-white p-3.5 rounded-xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <p className="font-extrabold text-xs text-slate-900 truncate">{pt.fullName}</p>
                    <p className="text-[11px] font-mono text-slate-500 tabular-nums mt-0.5">{pt.phone || 'بدون هاتف'}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenPatientDossier(pt.id)}
                    className="px-3 py-1.5 text-[11px] font-extrabold rounded-lg bg-teal-600 hover:bg-teal-700 text-white whitespace-nowrap shadow-xs transition-colors cursor-pointer"
                  >
                    الملف الطبي
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Local Storage on Device & Master Export Hub */}
      <div className="bg-white rounded-2xl border-2 border-teal-200/90 p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
                <HardDrive className="w-4 h-4" />
              </div>
              <h2 className="text-base sm:text-lg font-bold font-heading text-slate-900 tracking-tight">
                مركز التخزين المحلي الآمن والأرشيف الموحد
              </h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                حفظ محلي 100%
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              حفظ ملفات المرضى محلياً داخل مجلد مخصص على جهاز الكمبيوتر الخاص بك لحماية البيانات الطبية
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <label className="flex items-center gap-2 cursor-pointer bg-slate-50 hover:bg-slate-100 px-3.5 py-2 rounded-xl border border-slate-200 transition-colors">
              <input
                type="checkbox"
                checked={folderInfo.autoSaveEnabled}
                onChange={handleToggleAutoSave}
                className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500 border-slate-300 cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-700">
                الحفظ التلقائي عند التعديل
              </span>
            </label>
          </div>
        </div>

        {exportFeedback && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-900 flex items-center justify-between animate-in fade-in">
            <span>{exportFeedback}</span>
            <button
              onClick={() => setExportFeedback(null)}
              className="text-emerald-700 hover:text-emerald-950 font-bold px-1 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Card 1: Select Storage Folder */}
          <div className="bg-gradient-to-br from-teal-50/70 to-slate-50 p-4 sm:p-5 rounded-xl border-2 border-teal-200/90 flex flex-col justify-between space-y-3.5 shadow-2xs">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold font-heading text-teal-950 flex items-center gap-1.5">
                  <Folder className="w-4 h-4 text-teal-600" />
                  مجلد الحفظ المحلي المعتمد
                </span>
                {folderInfo.folderName ? (
                  <span className="text-[11px] px-2.5 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-full border border-emerald-300 flex items-center gap-1 shadow-2xs">
                    <Check className="w-3 h-3" />
                    مجلد نشط ومعتمد
                  </span>
                ) : (
                  <span className="text-[11px] px-2 py-0.5 bg-slate-200 text-slate-700 font-bold rounded-full">
                    المجلد الافتراضي
                  </span>
                )}
              </div>

              {/* Direct interactive editable input with instant confirm */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-teal-600">
                      <FolderOpen className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      dir="ltr"
                      value={folderInputVal}
                      onChange={(e) => setFolderInputVal(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleApplyFolder(folderInputVal);
                      }}
                      placeholder="مثال: D:\ClinicData أو C:\DentalClinic"
                      className="w-full pl-3 pr-9 py-2 bg-white border-2 border-teal-300 hover:border-teal-400 focus:border-teal-500 rounded-xl text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 shadow-inner transition-all"
                      title="اكتب أو عدل مسار المجلد مباشرة ثم اضغط اعتماد"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApplyFolder(folderInputVal)}
                    title="حفظ واعتماد هذا المسار"
                    className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs flex items-center gap-1 shrink-0"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>اعتماد</span>
                  </button>
                </div>

                {/* Quick 1-click presets right on the card */}
                <div className="flex items-center gap-1 flex-wrap pt-0.5">
                  <span className="text-[10px] font-bold text-slate-500">مجلدات سريعة:</span>
                  {[
                    { label: 'القرص D', path: 'D:\\ClinicData' },
                    { label: 'القرص C', path: 'C:\\ClinicData' },
                    { label: 'المستندات', path: 'Documents\\DentalClinic' },
                    { label: 'سطح المكتب', path: 'Desktop\\ClinicData' },
                  ].map(chip => (
                    <button
                      key={chip.path}
                      type="button"
                      onClick={() => handleApplyFolder(chip.path)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-mono transition-all border cursor-pointer ${
                        folderInputVal === chip.path
                          ? 'bg-teal-600 text-white border-teal-600 font-bold shadow-2xs'
                          : 'bg-white hover:bg-teal-50 text-slate-700 border-teal-200 hover:border-teal-300'
                      }`}
                      title={`اعتماد ${chip.path} مباشرة`}
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed pt-0.5">
                  يتم حفظ نسخ رقمية من ملفات المرضى، التقارير الطبية والنسخ الاحتياطية داخل هذا المجلد المعتمد.
                </p>
              </div>
            </div>

            {/* Hidden native directory input */}
            <input
              type="file"
              ref={hiddenFolderPickerRef}
              // @ts-ignore
              webkitdirectory=""
              directory=""
              multiple={false}
              className="hidden"
              onChange={handleNativeFolderSelected}
            />
            {/* Hidden native file input fallback */}
            <input
              type="file"
              ref={hiddenFilePickerRef}
              className="hidden"
              onChange={handleNativeFileSelected}
            />

            {/* Action Buttons */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsFolderModalOpen(true)}
                className="py-2.5 px-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                title="فتح نافذة خيارات وتحديد المجلدات"
              >
                <FolderCheck className="w-4 h-4" />
                <span>اختيار / تغيير المجلد</span>
              </button>

              <button
                type="button"
                onClick={handleSelectFolder}
                className="py-2.5 px-3 bg-white hover:bg-teal-50 text-teal-900 border border-teal-300 hover:border-teal-400 font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                title="فتح مستعرض ملفات الجهاز لتحديد مجلد"
              >
                <FolderOpen className="w-4 h-4 text-teal-600" />
                <span>استعراض جهازك 📂</span>
              </button>
            </div>
          </div>

          {/* Card 2: Save All in One File */}
          <div className="bg-linear-to-br from-indigo-50/70 to-slate-50 p-4 sm:p-5 rounded-xl border border-indigo-200 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold font-heading text-indigo-950 flex items-center gap-1.5">
                  <FileArchive className="w-4 h-4 text-indigo-600" />
                  أرشيف شامل لجميع المرضى
                </span>
                <span className="text-[11px] px-2 py-0.5 bg-indigo-100 text-indigo-800 font-bold font-mono rounded-full border border-indigo-300">
                  {patients.length} مريض
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                تجميع وتنزيل كافة سجلات العيادة، المرضى، المواعيد، وحالات الأسنان في ملف واحد مضغوط (ZIP) للاحتفاظ بنسخة خارجية.
              </p>
            </div>
            <div className="pt-2">
              <button
                type="button"
                disabled={isExportingAll || patients.length === 0}
                onClick={handleSaveAllPatientsInOneFile}
                className="w-full py-2.5 px-4 bg-linear-to-r from-teal-600 via-teal-700 to-indigo-700 hover:from-teal-700 hover:to-indigo-800 text-white font-extrabold text-xs rounded-xl shadow-md shadow-teal-700/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isExportingAll ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جارٍ حزم {patients.length} مريض...</span>
                  </>
                ) : (
                  <>
                    <ArrowDownToLine className="w-4 h-4" />
                    <span>تنزيل أرشيف المرضى الشامل (ZIP موحد)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Yearly Influx Chart */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-teal-600" />
              <h2 className="text-base sm:text-lg font-bold font-heading text-slate-900 tracking-tight">
                مخطط توافد المرضى الجدد خلال شهور سنة {currentYear}
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1 font-sans">
              توزيع تسجيل المرضى الجدد على مدار الـ 12 شهراً
            </p>
          </div>

          <div className="flex items-center gap-3 self-start sm:self-auto flex-wrap">
            <div className="hidden lg:flex items-center gap-3 text-xs text-slate-600 border-l border-slate-200 pl-3">
              <span>إجمالي المرضى الجدد: <strong className="font-mono tabular-nums text-slate-900 font-bold">{totalYearlyNewPatients}</strong> مريض</span>
              <span>•</span>
              <span>المعدل الشهري: <strong className="font-mono tabular-nums text-slate-900 font-bold">{avgMonthlyNewPatients}</strong></span>
              <span>•</span>
              <span>الشهر الأنشط: <strong className="text-teal-700 font-bold">{maxMonthItem?.monthLabel}</strong> ({maxMonthItem?.newPatients})</span>
            </div>

            <div className="flex items-center bg-slate-100 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setChartType('bar')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  chartType === 'bar'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="مخطط أعمدة"
              >
                <BarChart3 className="w-3.5 h-3.5 text-teal-600" />
                <span>أعمدة</span>
              </button>
              <button
                type="button"
                onClick={() => setChartType('area')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  chartType === 'area'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="مخطط بياني متصل"
              >
                <LineChart className="w-3.5 h-3.5 text-teal-600" />
                <span>منحنى</span>
              </button>
            </div>
          </div>
        </div>

        <div className="w-full h-72 sm:h-80 pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? (
              <BarChart
                data={yearlyChartData}
                margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
              >
                <defs>
                  <linearGradient id="patientBarGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0d9488" stopOpacity={0.9} />
                    <stop offset="100%" stopColor="#14b8a6" stopOpacity={0.65} />
                  </linearGradient>
                  <linearGradient id="activeBarGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0f766e" stopOpacity={1} />
                    <stop offset="100%" stopColor="#0d9488" stopOpacity={0.85} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis
                  dataKey="shortLabel"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                  tick={{ fill: '#64748b', fontWeight: 500 }}
                  interval={0}
                />
                <YAxis
                  allowDecimals={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                  tick={{ fill: '#64748b' }}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }} />
                <Bar
                  dataKey="newPatients"
                  name="المرضى الجدد"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={48}
                  fill="url(#patientBarGrad)"
                >
                  {yearlyChartData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.newPatients === maxMonthItem?.newPatients && entry.newPatients > 0 ? 'url(#activeBarGrad)' : 'url(#patientBarGrad)'}
                    />
                  ))}
                </Bar>
              </BarChart>
            ) : (
              <AreaChart
                data={yearlyChartData}
                margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
              >
                <defs>
                  <linearGradient id="patientAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0d9488" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#0d9488" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis
                  dataKey="shortLabel"
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                  tick={{ fill: '#64748b', fontWeight: 500 }}
                  interval={0}
                />
                <YAxis
                  allowDecimals={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                  tick={{ fill: '#64748b' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="newPatients"
                  name="المرضى الجدد"
                  stroke="#0d9488"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#patientAreaGrad)"
                  activeDot={{ r: 6, fill: '#0f766e', stroke: '#fff', strokeWidth: 2 }}
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Appointments Lists & LAN Hub */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Appointments Table */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold font-heading text-slate-900 tracking-tight">
                    مواعيد وجلسات اليوم ({new Date().toLocaleDateString('ar-DZ', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })})
                  </h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 font-mono font-bold border border-teal-200">
                    {stats.todayAppointmentsList.length} مواعيد
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 font-sans">
                  قائمة المرضى المسجلين لزيارة العيادة اليوم
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={onBookAppointment}
                  className="text-xs text-teal-800 hover:text-teal-900 font-bold font-heading flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors shadow-2xs cursor-pointer"
                >
                  <span>+ حجز موعد</span>
                </button>
              </div>
            </div>

            {stats.todayAppointmentsList.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-bold font-heading text-slate-700">لا توجد مواعيد مجدولة لهذا اليوم</p>
                <p className="text-xs text-slate-400 mt-1">يمكنك إضافة مواعيد جديدة بالضغط على زر &quot;حجز موعد&quot;</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-heading font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3.5 px-4 font-heading font-bold">التوقيت</th>
                      <th className="py-3.5 px-4 font-heading font-bold">اسم المريض</th>
                      <th className="py-3.5 px-4 font-heading font-bold">الهاتف</th>
                      <th className="py-3.5 px-4 font-heading font-bold">نوع الإجراء الطبي</th>
                      <th className="py-3.5 px-4 font-heading font-bold">الحالة</th>
                      <th className="py-3.5 px-4 font-heading font-bold text-center">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {stats.todayAppointmentsList.map(apt => {
                      const patient = getPatient(apt.patientId);
                      const isCompleted = apt.status === 'completed';
                      const isCancelled = apt.status === 'cancelled';
                      return (
                        <tr
                          key={apt.id}
                          className="hover:bg-slate-50/70 transition-colors"
                        >
                          <td className="py-3.5 px-4 font-mono font-bold text-slate-900 tabular-nums text-sm">
                            {apt.appointmentTime}
                          </td>
                          <td className="py-3.5 px-4">
                            <button
                              onClick={() => onOpenPatientDossier(apt.patientId)}
                              className="font-bold text-teal-800 hover:text-teal-950 hover:underline text-right block cursor-pointer"
                            >
                              {patient ? patient.fullName : 'مريض غير مسجل'}
                            </button>
                            {patient && (
                              <span className="text-[11px] text-slate-500">
                                {patient.patientType === 'new' ? 'مريض جديد' : 'مريض متابع'}
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-mono tabular-nums text-slate-600">
                            {patient?.phone ? (
                              <a
                                href={`tel:${patient.phone}`}
                                className="flex items-center gap-1 hover:text-teal-600"
                                title="اتصال هاتفي"
                              >
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span>{patient.phone}</span>
                              </a>
                            ) : '-'}
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-800">
                            {apt.procedure}
                          </td>
                          <td className="py-3.5 px-4">
                            {isCompleted ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                <CheckCircle2 className="w-3 h-3" />
                                مكتمل
                              </span>
                            ) : isCancelled ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-rose-50 text-rose-700">
                                ملغى
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                                <Clock className="w-3 h-3 text-slate-500" />
                                مجدول
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {!isCompleted && !isCancelled && (
                                <button
                                  onClick={() => onCompleteAppointment(apt.id)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold transition-colors whitespace-nowrap shadow-xs cursor-pointer"
                                  title="تحديد الموعد كمكتمل"
                                >
                                  إتمام
                                </button>
                              )}
                              <button
                                onClick={() => onOpenPatientDossier(apt.patientId)}
                                className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-[11px] transition-colors whitespace-nowrap cursor-pointer"
                              >
                                الملف
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Upcoming Appointments */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 sm:p-5 border-b border-slate-100">
              <h2 className="text-base sm:text-lg font-bold font-heading text-slate-900 tracking-tight">
                المواعيد القادمة للأيام القادمة
              </h2>
              <span className="text-xs text-slate-500 font-sans mt-0.5 block">
                استعراض جدول الأعمال للأيام المقبلة
              </span>
            </div>
            {stats.upcomingAppointmentsList.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-xs">
                لا توجد مواعيد قادمة مجدولة بعد اليوم.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-heading font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4 font-heading font-bold">التاريخ</th>
                      <th className="py-3 px-4 font-heading font-bold">الوقت</th>
                      <th className="py-3 px-4 font-heading font-bold">اسم المريض</th>
                      <th className="py-3 px-4 font-heading font-bold">الإجراء الطبي</th>
                      <th className="py-3 px-4 font-heading font-bold text-center">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {stats.upcomingAppointmentsList.map(apt => {
                      const patient = getPatient(apt.patientId);
                      return (
                        <tr key={apt.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4 font-mono font-medium text-slate-700 tabular-nums">
                            {formatDateDZ(apt.appointmentDate)}
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                            {apt.appointmentTime}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">
                            {patient ? patient.fullName : 'مريض غير مسجل'}
                          </td>
                          <td className="py-3 px-4 text-slate-700">
                            {apt.procedure}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => onOpenPatientDossier(apt.patientId)}
                              className="text-teal-600 hover:text-teal-800 font-semibold cursor-pointer"
                            >
                              عرض الملف
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Right Info Cards */}
        <div className="space-y-6">
          <div className="bg-teal-900 text-white p-5 rounded-xl shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Wifi className="w-5 h-5 text-teal-300" />
              <h3 className="text-sm font-bold">
                ربط الأجهزة على شبكة العيادة (LAN)
              </h3>
            </div>
            <p className="text-xs text-teal-100 leading-relaxed mb-4">
              يمكن لجميع أجهزة العيادة (كمبيوتر المساعد، التابلت، اللابتوب) الدخول إلى لوحة التحكم من خلال الرابط الداخلي:
            </p>
            <div className="bg-teal-950/80 p-3 rounded-lg border border-teal-700/60 font-mono text-xs text-teal-200 select-all mb-3 text-center" dir="ltr">
              {networkInfo.networkUrls[0] || `http://${networkInfo.primaryLanIp}:3000`}
            </div>
            <div className="text-[11px] text-teal-200 space-y-1">
              <p>• يعمل بالكامل على الراوتر الداخلي (WiFi أو كابل LAN).</p>
              <p>• تزامن لحظي بين جهاز الطبيب وجهاز الاستقبال.</p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2">
            <div className="font-bold text-slate-800">
              توجيهات النسخ الاحتياطي اليومي:
            </div>
            <p>• يتم حفظ كافة البيانات محلياً داخل مجلد العيادة على القرص الصلب.</p>
            <p>• احرص على الضغط على زر &quot;نسخ احتياطي&quot; يومياً بنهاية العمل.</p>
            <p>• احتفظ بملف الـ ZIP على فلاش ديسك USB خارجي لحماية البيانات.</p>
          </div>
        </div>
      </div>

      {/* FOLDER SELECTION MODAL */}
      {isFolderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-3 sm:p-4 backdrop-blur-2xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-5 sm:p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150 my-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
                  <Folder className="w-5 h-5 text-teal-600" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold font-heading text-slate-900">
                    تحديد مجلد الحفظ المحلي المعتمد
                  </h3>
                  <p className="text-xs text-slate-500">
                    اختر أي قرص ومجلد على جهازك لحفظ تقارير وبيانات المرضى
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFolderModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 rounded-md cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Option 1: Fast Visual Drive & Subfolder Builder */}
              <div className="p-3.5 bg-linear-to-br from-teal-50/80 to-slate-50 border border-teal-200 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-950 flex items-center gap-1.5 font-heading">
                    <HardDrive className="w-4 h-4 text-teal-700" />
                    الخيار 1: اختيار القرص والمجلد فوراً
                  </span>
                  <span className="text-[10px] text-teal-800 bg-white px-2 py-0.5 rounded border border-teal-200 font-bold">
                    سريع ومباشر
                  </span>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 block">اختر القرص:</span>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 text-xs font-mono">
                    {[
                      { drive: 'D:\\', label: 'القرص D:' },
                      { drive: 'C:\\', label: 'القرص C:' },
                      { drive: 'E:\\', label: 'القرص E:' },
                      { drive: 'Documents\\', label: 'المستندات' },
                      { drive: 'Desktop\\', label: 'سطح المكتب' },
                    ].map(d => (
                      <button
                        key={d.drive}
                        type="button"
                        onClick={() => {
                          setModalSelectedDrive(d.drive);
                          const combined = `${d.drive}${modalCustomSubfolder}`;
                          setFolderInputVal(combined);
                        }}
                        className={`p-1.5 rounded-lg border text-center font-bold transition-all cursor-pointer ${
                          modalSelectedDrive === d.drive
                            ? 'bg-teal-600 text-white border-teal-600 shadow-2xs'
                            : 'bg-white hover:bg-teal-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-600 block">اسم المجلد المطلوب:</span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      dir="ltr"
                      value={modalCustomSubfolder}
                      onChange={(e) => {
                        const val = e.target.value;
                        setModalCustomSubfolder(val);
                        setFolderInputVal(`${modalSelectedDrive}${val}`);
                      }}
                      placeholder="ClinicData أو DentalClinic"
                      className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleApplyFolder(`${modalSelectedDrive}${modalCustomSubfolder}`)}
                      className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs shrink-0 flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>اعتماد هذا المجلد</span>
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-teal-900 bg-white/90 p-2 rounded-lg border border-teal-200 font-mono truncate" dir="ltr">
                  المسار المختار: <strong className="text-teal-700">{modalSelectedDrive}{modalCustomSubfolder}</strong>
                </div>
              </div>

              {/* Option 2: Native OS Browser / File Selector */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5 font-heading">
                    <FolderOpen className="w-4 h-4 text-teal-600" />
                    الخيار 2: استعراض مجلدات نظام التشغيل
                  </span>
                  <span className="text-[10px] text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200 font-semibold">
                    مستكشف الملفات
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (hiddenFolderPickerRef.current) {
                        hiddenFolderPickerRef.current.click();
                      } else {
                        handleSelectFolder();
                      }
                    }}
                    className="py-2 px-3 bg-white hover:bg-teal-50 text-teal-900 border border-teal-300 hover:border-teal-400 font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer group"
                  >
                    <FolderOpen className="w-4 h-4 text-teal-600 group-hover:scale-110 transition-transform" />
                    <span>تصفح مجلدات جهازك 📂</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (hiddenFilePickerRef.current) {
                        hiddenFilePickerRef.current.click();
                      }
                    }}
                    className="py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    title="اختر أي ملف داخل المجلد المطلوب لاستخراجه"
                  >
                    <Save className="w-4 h-4 text-slate-600" />
                    <span>تحديد ملف داخل المجلد 📄</span>
                  </button>
                </div>
              </div>

              {/* Option 3: Custom Text Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block font-heading">
                  الخيار 3: كتابة أو لصق المسار كاملاً:
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={folderInputVal}
                  onChange={(e) => setFolderInputVal(e.target.value)}
                  placeholder="مثال: D:\DentalClinic أو C:\ClinicData"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white font-bold"
                />
              </div>

              {/* Option 4: Fast Quick Presets */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-500 block">
                  أو اختر أحد المجلدات المقترحة بنقرة واحدة:
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { label: 'القرص D (بيانات العيادة)', path: 'D:\\ClinicData' },
                    { label: 'القرص C (بيانات العيادة)', path: 'C:\\ClinicData' },
                    { label: 'المستندات (Documents)', path: 'Documents\\DentalClinic' },
                    { label: 'سطح المكتب (Desktop)', path: 'Desktop\\ClinicData' },
                    { label: 'القرص E (ملفات المرضى)', path: 'E:\\DentalClinic' },
                    { label: 'المجلد الافتراضي للعيادة', path: 'clinic_data/patient_files' },
                  ].map(item => (
                    <button
                      key={item.path}
                      type="button"
                      onClick={() => {
                        setFolderInputVal(item.path);
                        handleApplyFolder(item.path);
                      }}
                      className={`p-2 rounded-lg border text-right transition-all cursor-pointer font-sans ${
                        folderInputVal === item.path
                          ? 'bg-teal-100 border-teal-400 text-teal-950 font-bold'
                          : 'bg-slate-50 hover:bg-teal-50/60 border-slate-200 text-slate-700 text-[11px]'
                      }`}
                    >
                      <div className="font-bold truncate">{item.label}</div>
                      <div className="font-mono text-[10px] text-slate-400 truncate" dir="ltr">{item.path}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setIsFolderModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => handleApplyFolder(folderInputVal)}
                className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>تأكيد واعتماد هذا المجلد</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
