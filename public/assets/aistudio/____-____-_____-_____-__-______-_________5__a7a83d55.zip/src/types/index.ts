export interface User {
  id: string;
  clinicId?: string;
  clinicName?: string;
  username: string;
  fullName: string;
  role: 'doctor' | 'assistant';
  isActive?: boolean;
  mustChangePassword?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Patient {
  id: string;
  clinicId?: string;
  fullName: string;
  phone: string;
  birthDate: string;
  gender: 'male' | 'female';
  address: string;
  allergies: string;
  patientType: 'new' | 'returning';
  diseaseCondition?: string; // e.g. "علاج تسوس الأسنان", "جراحة الفم والفكين", "تقويم الأسنان"
  diseaseStatus?: 'active' | 'under_treatment' | 'completed' | 'stable' | 'urgent';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:mm
  procedure: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  cost?: number; // DZD (دينار جزائري)
  paymentMethod?: 'cash' | 'baridimob' | 'check';
  notes?: string;
  smsReminderSent?: boolean;
  smsReminderSentAt?: string;
  createdAt: string;
}

export interface FinancialStats {
  totalRevenueYear: number;
  totalRevenueMonth: number;
  totalRevenueWeek: number;
  totalCompletedAppointments: number;
  averagePerAppointment: number;
  monthlyRevenue: {
    month: string;
    monthLabel: string;
    revenue: number;
    completedCount: number;
  }[];
  weeklyRevenue: {
    weekLabel: string;
    weekNumber: number;
    startDate: string;
    endDate: string;
    revenue: number;
    completedCount: number;
  }[];
  dailyRevenueThisWeek: {
    dayName: string;
    date: string;
    revenue: number;
    count: number;
  }[];
  procedureBreakdown: {
    procedure: string;
    revenue: number;
    count: number;
    percentage: number;
  }[];
}

export type ToothSurface = 'Occlusal' | 'Mesial' | 'Distal' | 'Buccal' | 'Lingual' | 'Incisal' | 'All';

export interface ToothSurfaceCondition {
  surface: ToothSurface | string;
  conditionType: string;
  diagnosis?: string;
  treatmentPlanned?: string;
  treatmentDone?: string;
  status: 'in_progress' | 'treated' | 'monitoring';
  cost?: number;
  notes?: string;
  updatedAt?: string;
}

export interface ConditionHistoryEntry {
  id: string;
  date: string;
  conditionType: string;
  surface?: string;
  surfaces?: string[];
  diagnosis?: string;
  treatmentPlanned?: string;
  treatmentDone?: string;
  status: 'in_progress' | 'treated' | 'monitoring';
  doctorName?: string;
  cost?: number;
  notes?: string;
}

export interface DentalCondition {
  id: string;
  patientId: string;
  toothNumber: number; // 11-48 for permanent, 51-85 for deciduous
  conditionType: string;
  surface?: ToothSurface | string;
  surfaces?: string[]; // e.g. ['O', 'M', 'D', 'B', 'L']
  surfaceDetails?: Record<string, ToothSurfaceCondition>;
  diagnosis?: string;
  treatmentPlanned?: string;
  treatmentDone?: string;
  doctorName?: string;
  status: 'in_progress' | 'treated' | 'monitoring';
  cost?: number; // DZD
  recordedDate: string;
  notes?: string;
  visitId?: string;
  history?: ConditionHistoryEntry[];
  updatedAt?: string;
  createdAt: string;
}

export interface ClinicalNote {
  id: string;
  patientId: string;
  noteText: string;
  doctorName: string;
  createdAt: string;
}

export interface PatientFile {
  id: string;
  patientId: string;
  originalName: string;
  storedName: string;
  filePath?: string;
  fileSize: number;
  mimeType: string;
  category: string;
  uploadDate: string;
  dataUrl?: string; // For client-side preview fallback
}

export interface ClinicSettings {
  clinicName: string;
  doctorName: string;
  phone: string;
  address: string;
  storagePath: string;
  autoBackupDaily: boolean;
  // SMS Gateway Settings
  smsEnabled?: boolean;
  smsProvider?: 'local_simulator' | 'custom' | 'twilio' | 'infobip';
  smsSenderName?: string;
  smsApiKey?: string;
  smsApiUrl?: string;
  smsAccountSid?: string;
  smsAutoSend24h?: boolean;
  smsReminderTemplate?: string;
}

export interface SmsLog {
  id: string;
  appointmentId?: string;
  patientId?: string;
  patientName: string;
  phone: string;
  message: string;
  status: 'sent' | 'failed' | 'simulated';
  provider: string;
  sentAt: string;
  error?: string;
}

export interface NetworkInfo {
  port: number;
  localUrl: string;
  networkUrls: string[];
  primaryLanIp: string;
}

export interface DashboardStats {
  todayAppointmentsCount: number;
  todayAppointmentsCompleted: number;
  todayAppointmentsScheduled: number;
  newPatientsThisMonth: number;
  returningPatientsCount: number;
  newPatientsCount: number;
  totalPatientsCount: number;
  todayAppointmentsList: Appointment[];
  upcomingAppointmentsList: Appointment[];
  monthlyDistribution: { month: string; monthLabel: string; count: number }[];
  yearlyDistribution?: {
    month: string;
    monthLabel: string;
    shortLabel: string;
    newPatients: number;
    year: number;
  }[];
  currentYear?: number;
}
